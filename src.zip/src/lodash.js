// import React from 'react'
// import _ from 'lodash'
// const Lodash = () => {
//     let array = _.fill(Array(4),0)
//     console.log('lodash',array)
//     let greetFunction = _.partial(func , 'hi')
//     console.log(greetFunction('javhaa'))

//     return (
//         <div>
            
//         </div>
//     )
// }

// export default Lodash
