import React, { useState } from "react";
// import Start from './components/start/start'
import { Start, Next, Banner, Section, Shops, Categories, products, CategoryProducts, CartItem, Carts, Detail, BottomBar, Favorites } from './components'
import { BrowserRouter as Router, Routes, Route } from "react-router-dom";
import { CatigoriesItemDisplay } from "./components/explore/catigoriesItem-display";
import { ShopProvider } from "./provider/shop-context";
import rice from './picture/rice.svg'
import Lodash from "./lodash";

function App() {
  const [wait, setWait] = useState(false)
  setInterval(() => {
    setWait(true)
  }, 3000)

  return (
    <ShopProvider >
      {/* {wait ? <Next /> : <Start />} */}
      {/* <Banner />
      <Section tittle='Exclusive Offer' /> */}
      <Router>
        <Routes>
          <Route path="/" exact element={wait ? <Next /> : <Start />}></Route>
          <Route path="/market" element={<Banner />}></Route>
          <Route path="/Explore" element={<Categories />}></Route>
          <Route path='Cart' element={<Carts />}></Route>
          <Route path='/Explore/detail/:category' element={<CatigoriesItemDisplay />}></Route>
          <Route path='/market/detail' element={<Detail />}></Route>
          <Route path='/Favorite' element={<Favorites />}></Route>
        </Routes>

      </Router>
      {/* <CatigoriesItemDisplay /> */}
    </ShopProvider>
    // <Lodash />
  );
}

export default App;



// state "spalsh" , "onboarding"

// setInterval(() => {
//   setState("onboarding")
// }) 