import React from 'react'
import '../../index/index.css'

const Start = () => {
    return (
        <div className='Start' >
        </div>
    )
}

export {Start}
