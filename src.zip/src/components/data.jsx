import banana from '../picture/banana.svg'
import apple from '../picture/apple.svg'
import strawberry from '../picture/strawberry.jpeg'
import kiwi from '../picture/kiwi.jpeg'
import tomato from '../picture/tomato.jpeg'
import orange from '../picture/orange.jpeg'
import pulses from '../picture/pulses.svg'
import rice from '../picture/rice.svg'
import Fruit from '../picture/pngfuel 6.png'
import Oil from '../picture/pngfuel 8.png'
import Meat from '../picture/pngfuel 9.png'
import Bakery from '../picture/pngfuel 6 (1).png'
import Dairy from '../picture/pngfuel.png'
import Fruit1 from '../picture/pngfuel 6.png'
import Oil1 from '../picture/pngfuel 8.png'
import Meat1 from '../picture/pngfuel 9.png'
import Bakery1 from '../picture/pngfuel 6 (1).png'
import Dairy1 from '../picture/pngfuel.png'
import Beverages1 from '../picture/pngfuel 6 (2).png'
export const products = [
    {
        ProductName: 'Organic Bananas',
        desc: '7pcs, Priceg',
        price: 4.99,
        img: banana,
        quantity: 1,
        name: 'product'
    },
    {
        ProductName: 'apple',
        desc: '1kg, Price',
        price: 4.99,
        img: apple,
        quantity: 1,
        name: 'product'
    },
    {
        ProductName: 'Strawberry',
        desc: '1kg, Price',
        price: 6.99,
        img: strawberry,
        quantity: 1,
        name: 'product'
    },
    {
        ProductName: 'kiwi',
        desc: '1kg, Price',
        price: 4.99,
        img: kiwi,
        quantity: 1,
        name: 'product'
    },
    {
        ProductName: 'tomato',
        desc: '1kg, Price',
        price: 2.99,
        img: tomato,
        quantity: 1,
        name: 'product'
    },
    {
        ProductName: 'orange',
        desc: '1kg, Price',
        price: 5.99,
        img: orange,
        quantity: 1,
        name: 'product'
    },


    {
        tittle: 'Pulses',
        img: pulses,
        color: ' #F8A44C',
        name: 'groceries'
    },
    {
        tittle: 'Rice',
        color: '#53B175',
        img: rice,
        name: 'groceries'

    },
    {
        tittle: 'Flour',
        color: '#D3B0E0',
        img: 1,
        name: 'groceries'
    },
    {
        tittle: 'Meat',
        color: '#F7A593',
        img: 1,
        name: 'groceries'
    },




    {
        ProductName: 'Frash Fruits Vegetable',
        desc: '2l',
        price: 4.99,
        img: Fruit,
        quantity: 1,
        name: 'bestSelling'
    },
    {
        ProductName: 'Cooking Oil & Ghee',
        desc: '1l',
        price: 4.99,
        img: Oil,
        quantity: 1,
        name: 'bestSelling'
    },
    {
        ProductName: 'Organic Bananas',
        desc: '7pcs, Priceg',
        price: 4.99,
        img: apple,
        quantity: 1,
        name: 'bestSelling'
    },
    {
        ProductName: 'Organic Bananas',
        desc: '7pcs, Priceg',
        price: 4.99,
        img: Bakery,
        quantity: 1,
        name: 'bestSelling'
    },
    {
        ProductName: 'Organic Bananas',
        desc: '7pcs, Priceg',
        price: 4.99,
        img: tomato,
        quantity: 1,
        name: 'bestSelling'
    },
    {
        ProductName: 'Organic Bananas',
        desc: '7pcs, Priceg',
        price: 4.99,
        img: strawberry,
        quantity: 1,
        name: 'bestSelling'
    },
    {
        ProductName: 'Organic Bananas',
        desc: '7pcs, Priceg',
        price: 4.99,
        img: Meat,
        quantity: 1,
        name: 'bestSelling'
    },




    {
        desc: '355ml, Price',
        quantity: 1,
        name: 'bottomSale',
        img: 'https://cdn11.bigcommerce.com/s-kknankib6z/images/stencil/1280x1280/products/11169/32042/coca-cola-diet-coke-355mlcoca-cola-04965802__17690.1600137023.jpg?c=2?imbypass=on',
        ProductName: 'Diet Coke',
        price: 1.99,
    },
    {
        ProductName: 'Organic Bananas',
        desc: '7pcs, Priceg',
        price: 4.99,
        img: banana,
        quantity: 1,
        name: 'bottomSale'
    },
    {
        desc: '355ml, Price',
        quantity: 1,
        name: 'bottomSale',
        ProductName: 'Diet Coke',
        price: 1.99, img: strawberry,
        name: 'bottomSale'

    },
    {
        ProductName: 'Organic Bananas',
        desc: '7pcs, Priceg',
        price: 4.99,
        img: tomato,
        quantity: 1,
        name: 'bottomSale'
    },
    {
        ProductName: 'Organic Bananas',
        desc: '7pcs, Priceg',
        price: 4.99,
        img: apple,
        quantity: 1,
        name: 'bottomSale'
    },
    {
        ProductName: 'Organic Bananas',
        desc: '7pcs, Priceg',
        price: 4.99,
        img: Meat,
        quantity: 1,
        name: 'bottomSale'
    },
    {
        ProductName: 'Organic Bananas',
        desc: '7pcs, Priceg',
        price: 4.99,
        img: kiwi,
        quantity: 1,
        name: 'bottomSale'
    },


    {
        img: 'https://cdn11.bigcommerce.com/s-kknankib6z/images/stencil/1280x1280/products/11169/32042/coca-cola-diet-coke-355mlcoca-cola-04965802__17690.1600137023.jpg?c=2?imbypass=on',
        name: 'Diet Coke',
        nameDetail: '355ml, Price',
        price: 1.99,
        category: "Beverages",
        quantity: 1

    },
    {
        img: 'https://i1.wp.com/trolleycentre.com/wp-content/uploads/2020/05/sprite-1.jpg?fit=1280%2C1280&ssl=1',
        name: 'Sprite Can',
        nameDetail: '325ml, Price',
        price: 1.50,
        category: "Beverages",
        quantity: 1
    },
    {
        img: 'data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEAAoHCBYVFBgWFRYYGBYZGRgcGhgYGhgZHRoeHhoaGRkaGRocIS4lHB4rIxgYJzgmKy81NTU1HCQ7Tjs0Py40NTEBDAwMEA8QHxISHzQsJSw/NzQ0Pzc0MTQ0OjE2PTQ0MTE2NjU6NDQ0NDQ0NDQ9MTQ0NDY0NjQ0NDU0NjQ0MTQ0NP/AABEIAOEA4QMBIgACEQEDEQH/xAAcAAEAAQUBAQAAAAAAAAAAAAAABwEDBAUGAgj/xABFEAACAQIEAgYFCQYEBgMAAAABAgADEQQSITEFQQYTIlFhcQcygZGxFEJScoKhwdHwIzOSwtLxYpOy4RUWU1SDohckQ//EABoBAQADAQEBAAAAAAAAAAAAAAABAgMFBAb/xAAqEQACAgEEAAYBBAMAAAAAAAAAAQIRAwQSITEFE0FRYZEUIjJCcRVSgf/aAAwDAQACEQMRAD8AmaIiAIiIAiIgCIiAIiIBSYvEMYtGk9V75UUsbamw7h3zKnO9PHy8Prn/AAge9lH4wVk6i2jkMR6TqhJ6ugqjlmYsfMgZbeV5q8T6TsaPVSgPsOf55ouF4MVFJZsoH63M1nEqeViqkMBzuD8JLpI5cc2Zs6Q+lbHj5mGPnTqfhUmx4b6YHDAYjDqV+c1JiCPEI97+WYSM3vLTIbH2yp6o5J+p9XUnDKGBuGAIPeCLiXJrOjdbPg8M30qFFveimbOSewREQBERAEREAREQBERAEREAREQBERAEREAREQBERAKTVdIeHNiMNUoq+RnUDPlDW1BNgdjYWB3F7jUTZOwAJJsBqSeUifpp6TCc1DAnwOI3v39UP5z7Bs0htItGEpukRhicF1depSqMxNN3QkAEkoxU2JGu2+kxq9Nb9nrfayg+4TNSgXux1vqSWF7k6kljcnxnpqWlgQB46+dm/vMnP0OjHTXE1gpDnn/iWbHo5wo4nFUqCOyM7WvpcWUsTcDSwUnb855NJrcj4i35/hKUndWV0ZlZTdWQ5WUjYgjUHxhTInpuOD6d4bhTSo06ZYMURVzBQgNgBfKNFvbYaTMkVdB/SSzutDGkZiQqVwMoJ2C1ANASfnCw1FwN5Ks1TTOfODi6ZWIiSVEREAREQBERAEREAREQBERAEREAREQBERAKSzXrKis7sFVQWZmNgoAuSSdgBLxkS+krpEaznCU2IooR1rLu7A6Ux/hU2v4/V1rJ7VZrhxSyy2o03TzprUxbtRw7FcKNDluDW0BJa4uE3AXna53sOVo4NSND2j8yxv7+c2FPCHcKFQfNtqRzudyfGZNGmL6gWGmneOfnPPKbZ3cOnjCNJGsXDW01Gmxlt8Mt9dTNjiH2Hdz7/H4SwwsfKUs9Dgq6MFqHcLR8nB3FjzmZaeWEmyPLRratDu/XdJA6BekBqJGHxjFqOyVWuWp9yud2Xx3Xy247JPD0QZaM2jzZdNGapn0vTqBgGUgggEEG4IOoII3EuSIfRf0nNNxg6zdhj+xJPqtzTybceNxz0l6eiLtWcTNiljltZWIiWMhERAEREAREQBERAEREAREQBERAEREA5vprxv5HhWdf3jdin9Zr9ryAufYBzkMYMAqz3LWPfuTrqfeZ3vpoRuqwzD1Q7g+ZUZfg0j3g2IVUy3tf43uPy9sxyK2dfQ/phaXLfJs0xalezpysfmkfr7pjNXCggD28/O8wq/Za42O8s9bfTvvrrpbWYNtnTSUS61S5lC0sIxvyIBt9wJP3yt9CfrfdFE7i6GvtPCXNte/8p6TQeQHwlUWwHgLQKsZPj+EqFnqUMFqRYrOFsc2UggqwOoIO4trcaayfOh/GvleFp1TbPbLUt9NdGPgDow8GE+fsbTzHewUH9fdJe9D2GZcGzNs9TsjwVVUn3gj7M2xdnJ8QVq2uuiQoiJucgREQBERAEREAREQBERAEREAREQBERAOV9I2AFbh1e+9NetU9xTtH3rmHtkF4egCo11tJ/wCmwY4DEhAWY02FhvY6MfYLn2SE+H0UykMLEHTy5TDLy1R1vDn+l31ZhEnLlY3Pf8DMdTY+w+82/KbRcMDmPIfr9eYmvxChdbzJHTkn9HhL/eT7+XuEur+vbvMQYkT38q8DFMopL3MwGehMEYy26mehxFe5vukUy6yRXbM2eNbnz/CUo11b1Z65wXtSVosV7ZSOdjPoPophFo4LDouwpJfxLAMx9pJPtnz9WIUeen5z6E6MB/kmHFQFXFGmGB3BCKDfuPhNsPbOV4l1E20RE3OQIiIAiIgCIiAIiIAiIgCIiAIiIAiIgHJ9POPVMJQU0lUtUfJmYEhdCduZsDa+mh3kTYcZaRPhb36fjJA9K3FwlOnhgisapzFmv2QrCxUD5xOl+6+95H6eoL94PuBP5Tz5OZJI7Wgio4ra7f2eKhsoX2n9frlNc6ZmudQNh+MzWa9yf14TFY6zK+TpVwrKiLysQSUvKGep5gFhqNmDLp3gcxLrH9eE9TyDrbu1Hkbgj2W+EFaS6Lap2s2t76Hu8u6Tt0F4vUxWFD1bZwzIWAsGy2s1tr62NtLg7bSDKZ3B5foGSx6MOkHXI2FKhTQVSrL85SzA5l5MDa5v2sxOk1xPk53iEE8e5L1JBiInoOKIiIAiIgCIiAIiIAiIgCIiAIiIAiIgEY+l3qf/AK983X9vKBa2TTPn9uW1vGcLTN1t5zrfTDUC18OT/wBN/wDUs4mnjVy7zy5LcuDv6HasKtnl3GYKTa408bEX/D75bZdZYxypUtZtRMTq3XZz7/8AeVUU12bTyyjJ8Wvhmziao1ao+f8Acv5SorVfpj3L+Unb8or+Sv8AV/RtBE1gqVfp/cv5St6p+f8A6fyjb8lvyL/izZTybZhqLgN52t+eWYIpOd3PvP4S9h6Kp2idZFJEqbl6V/ZkmSN6IXog11CkYg5WZjqDTGihe6xJv33GptYRqcQp2ufITvfQ9UDYiva/7pd/rf2lsf7jz66nhfJL0RE9RwRERAEREAREQBERAEREAREQBERAEREAjH0uupWjTyDrCHZKpJ7ABUOpABuCCORtYecjqhw97Xbqx7HP8skX0sUz12EbkBWBPdc0rH3/ABmswuGBWxFtOX5f2nmySSlyUetz4ntxtV8qzksPwqq98hpaX3zjbf5kuv0bxIUt+yYDWylybeAyazd4fDulRurp1HUm4ZKbt4chbcTc1sS1EIXpsma5UMpTUDtetbQXvfxA3mcnJcpEx8T1LXLX0cDU4TWWxJpWNu1dyNdiTk2nl+FVhVWlmp53tlsWtzO+TuBM6XF8RQggZCCb6Ei19Ta4A3v5TRY3G5MrBkBQ3Sz5iAb3QgctdPM+FpTv0H+S1F9r6LzdFcSBfNR7/Wbz+hPOG6N4l/Val7WcfyTrujOH+XUwoxVOnUZS3VBc7qgbKXZc4yhiVIvyIPOUoUlVjh8JUq4qqlRkrZaToqZLrYsdNWuAb2OU90nbOro0/P1XfocVxThNbD5esandjYBWcnuv6m0t0MBVfZk/9/6J1GL4bXrY1Uq0HVyp6pHKjMFF3YOTla1ybA6Xm9bhXUBGdQFZiqlWVgWAa63U72Vv4TDtRtoq/EtXzVfRwTcDrgXLIP4/6JIfokdQtenk/aoyF6vNw+fKtuQXIfO+0uOilSyDNYE9kEnT4ecu+jTD5KmLvu3UE27/ANrGGacuin5moyvbNqvgkGIiesuIiIAiIgCIiAIiIAiIgCIiAIiIAiIgHOdJuEJiXoq9yo6wEDmDkuPunJcYq0adUpRpsaaDKxVgRcaEAMdQLWJzakHTv7/HpmKjMVJDgMu6kgDMtwRcbi4nC8Q6HYnDi+GKV1Fzlfsv5C5yN59kzDNC1wjDMn/Ff2Z3QHiNSpUrhnfqaSJlRkVFUszkkWGYnsEkkn1pq+AcNGNwmGxNek+IariK+Y1K1a1GiXqElVD2sOqpqFAsbjzmLhOkLYWnXpPhMQlRwcxIyoilcgZXa+YAlj+drynDuM4jDjCIlELTwysrgVMxrKygHQoMpzAMNTrYeMmMoxilIRmqSkUw+Hwa4CviaK4YI+JYYapjKecBFyqVGYFmuUqlQde0L2tLVHiBw/BaNdaq4bEVqlZ1K0FqGp2qrLRUEEIp7NmNwoljiXSik+XD0KFAUBUZgmMpBslR3dma61iAl6jbqLA21Es1OO1wqI2PwqqgsmSmrNsbkZqb5WPeCNTLboro9kdLkktyVIveg7C2rYqq3zEppc7jMzMwv/41v7JsONYSrX4ThhgqbOMS/W4gUjqz1AzuKjD5ockEk2GRQdBac3g8StClanjMQiNqRTpMuYi6qS4KkmyqPWI8d5cwlKkEIotibPplVjTubm7MocKRbKO0W56DlG9UPIpVKcV/0kTheKRa2HwzOtSpg8KTXqA3y1CKdNUzH5zAVDYm9lHfI44fxqrXNChlLBAWSjRGa7Pd3qOWJLuczk6ADMdBrPC4Oilw2FzldUFSoi6Wseyg5Nrbnfw16voh0RNX9uctOmxugRixVQbgAnVW/wAR1FhKylv4Rnlxw2tRmm/ZepvOiXDMXSrF3pqtF1sVZlzqRqpAUsLciM3MHlN/wjBolWsyKFL5M1uds9tNhudu+bVRYW+JJ+8zDwHr1Ps/zTSMUkkZwgoqkbCIiXLiIiAIiIAiIgCIiAIiIAiIgCIiAIiIBr+JetT+sfhM1lBFjqCLEGYXE96f1vwmLjOI1FqlFQlbIQ3VuQSxYFMw0B0BzHRb6iKsGLX6GYNr/ssgO6ozIp+ypsPZMLiXRAKijC9nIAAjszAgbWZiSD4HTbabLC8TrkpmonKzBSQjgi4U3IY3AUtlJO+VjptFTiFcliiEL1hRQ9Fy1wG1OVrZCQLNoLML63kPDF8UijxRfocvR6K1Pkzs1K1cVC2U5GLIFUZQQSDzI17xzmRhugS1rNi9rg9UmlvAuNfYvvm3rcWxIDladyGIUHD1+0M6KH9bsixbs79nNsZ0OFcsiswsxUEixFiQCRY6jyMjykuSFiijl6nQmiCRTJFJj2qTEsFBtmyE6gG3qm47rbHa43o3hqty1JVY/OTsN5nLv7bzZ4iuqKWY2ABJPgJyWKxdeuCyZggNso7vHUa+ffymctsfTs3xaVZL6S+ejbcI4MmFR7sal2LXZRmACgAabnQ66XLGbPDIwuWYlm1I5Lpoq+A7+Zv4AcTVqmkCCCNLns2Ojb763IP3+EtYbiNN1GfO3NGLMy6m+wF1002MyWbmmqotmwLBFVzfwSJeYGA/eVPs/wA04+hxg0H0JbU3UNdWB2BvtYc7C+njOt4ZUDMzLqpVCD4G5E3hkUjCMrNpERNCwiIgCIiAIiIAiIgCIiAIiIAiIgCIiAYHEt6f1/wM13E61cYimUV+qp2zWIAfPdW0OhyAK2ttyBc6TY8S3p/X/AzV8T4dUasGCBu1SKuSLooJ6xFuQQToQRvz9UXtGr5JRrRxDFMqFHqEuDk7NC7sEcsLEACmGWkL6HtttoVzuGri1qqrBxRz1SQxR7q1Suy3csWFgaAUDYG1tDlxxg8YgpsWZwFBqguScxQrVyZNTqA6izHUgZLAH1gcLjGFFi7Kt0ZlZmzDSjnLXGxy1rKQbZxoNMmjquKJOsnJdJOmaYWo1O12ULe4O7agabaW18Z0+KrimjO3qorMbdygk/CfPWK47iXd26xmKB27XK7roRpfT2aTEmEdx0//ADrWxnWBhlpAouQWsWu7XvYMPVXS5l7h3EKlK7K25APMAaEj2X8fy4bgnEmao+e5dip8SdgLfredBjVegpLhcnMhlbLdbWNie8C88WZScm4nb0zxxxqMq5MpuJOwZ2JJZhv4DS38R28JZwldkc7sjEm3cSNT7QdR7fPBwZJIVrjmAwI3APP2TcUKdl/XO1zMWmpHozQx5ce2uDJNF3uUU30+ib+4k/2kgdEyerswIYKgIIsQQWGo905jo5TvWUDYfl/v987jA/vKn2f5p6NPF22fP59MsEqTuzYRET1mIiIgCIiAIiIAiIgCIiAIiIAiIgCIiAYHE/mfX/AyxjAM5vl5XuHva3+HTlL3FD+7+uPgZyHH+mValjDhqSooUC7uj1CxNPrLqiMptbTS5uDLwhKTpEpWdACulstlIt+8PM/hz2l7Auqtewvlt2Q/eLetOR/5uxeaxNK2uvyXECxuAAR12xve+1hyuL0XpbizYZ6JJI0GGr/SysBepe4v91rG4l/ImTR1/SnFPSwlV6aB2Cjsn6JIDm3OyljbwkK4DjASozkKoAIdAoJ1OgVbert4aGdfU6X4jEcPxJampZGVSyAhSrgkizE2bsgHX567GR/xLiL1FHYVLMLKNbaW0Y7DvmORODcX2bYY32Zr4tHZWCBX7RLkXIHaOtzZtTsba21lviVQhC9KqzorLmzjXkFb2MQdR3d0w2oAsoRyzWBN1y2NtrHe2mss1McxOQKpAKlgLdq1msb+w7TNOj0pWzfYbFNk6yq+fQKpI1BtlGvhYe6bLDVwyg+23K1jf3n4TmcTSSpRzouR0tnUaBrsFuBsDqDp3W7pu+CUy4VQTc6EtrlHPUe37phlg5co9ODLGHD9zvug+HLMz27IFtra/oTqsB69T7P80scEREpKibAb8yeZMv4D16n2f5pvijtjRzNTl8zI5ehsIiJoYCIiAIiIAiIgCIiAIiIAiIgCIiAIiIBy/S3j9LCthxVOVXcktqQoUAaga2u/LuM2HV4PFgPlw+IFrBrU6mm9gdbeUj300YfM+GOtstYaHmDTPlzkb0sGo3zE94Nj8JR5NrPbi0kskFJH0d/wDC/9tQ/yqf8ATK/8Dw3/AG9D/LT8p84VKLHZ2t3FifxE8/JhbVj7z+cjzvkutBP3PpgYKkENMIgQ37IVQuu/ZtacHi/RdSdywxNREJuECrZR3Anl5yFnpgePnKUKIZgCLAncXvsdpLknyyiwSjLapcv4JkxPovJe9PFBE00anmbx7QcD7vfN1jug9Orhkw7VABT/AHbqgDKT6xvmuS2pNybnXexkCYjDqrALrprmvKmmP9xeRuiafjzbpvr4Jno+i5LZXxDsnNVQITz9bMZ1nCujeGw6hadMac2JYn2mfO64dbesfaWleo5ZzaV8yPsWeiyNcyPpetXp01LMyoo3LEKB5kzRdHekeHxGIr0qLhygVswvY6kNlJ9YC66jTWQJ8iG5JPunfeh/C2xlVgNFoFT9p0I/0GTHJbozyaJwg5t9EyxETU8AiIgCIiAIiIAiIgCIiAIiIAiIgCIiAR76UcKz0VIUnq2zaanKQVb4g/ZkVrY7T6LxeEVxYzl8f0Lo1CSUW53IGU+9bGZTx7naOjpNasUdslaITxBsZj1nsLd8lfE+jekx2ceTn8ZaHoxonfP/AB/7Sixs3lrsbtoiJjCtaTCPRfh/ov8A5jT2voxw30G/zH/qmmw8r1UbshxqhY3Mv0luPCTGno1ww/8Az971D8Wl1vR5hyLdWP4n/qlXBsvDVwX7rIbR9cpnqlo/h5yXP/jbDf8AS/8Aep/VL9D0eYddqS+0sfiZXy2bLX4/ZkVnu79AO/ykk+jLhz0s7upXrMgAOhyrmNyOVy23hOmwPRWlT9VFX6qgfCb3DYRUGgl4Y9rtmOp13mx2xVIyJWImpzhERAEREAREQBERAEREAREQBERAEREASkrEA8GBEQQVlYiAIiIJECIggrKSsQSIiIAiIgCIiAIiIAiIgH//2Q==',
        name: 'Apple & Grape Juice',
        nameDetail: '2L, Price',
        price: 15.99,
        category: "Beverages",
        quantity: 1

    },
    {
        img: 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSL8Fe8JYW4EKS_BsBSdlgS5PVzxbVk0FvTtQ&usqp=CAU',
        name: 'Orenge Juice',
        nameDetail: '2L, Price',
        price: 15.99,
        category: "Beverages",
        quantity: 1

    },

    {
        img: 'data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEAAkGBxISEhUQEBAVFRUWFRUVFhUVFRUVFxAYFREWFxgVFxUYHSggGB4lHhUVIjEhJyorLi4uFx8zODMsOSgtLisBCgoKDg0OGxAQGyslICYtLS0tLy0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLf/AABEIAOEA4QMBIgACEQEDEQH/xAAcAAEAAQUBAQAAAAAAAAAAAAAABQMEBgcIAgH/xABOEAABAwICBAkGCgcGBgMAAAABAAIDBBESIQUGBzETIkFRYXGBkbEUMkJScqEjMzVigoOytMHRQ3OSorPC8BUkJVNj0lRkk6Ph8RY0RP/EABoBAQACAwEAAAAAAAAAAAAAAAADBAIFBgH/xAA0EQACAQIDBAkCBwADAAAAAAAAAQIDEQQhMRJBUXEFEzJhgZGhwdEzsSIjQlJi4fAUFST/2gAMAwEAAhEDEQA/AN4oiIAiIgCIiAIi+FAUJquNmT5GN9pwHiVSGlIDulYeo38FpTaBO6DSk5jwuLxE8kg8UmIDD+6D2q3g1tqRuMY+gf8AcsHUSLlHAV6yTgsuaN7iujPpe535L6axnre4/ktIf/L6v12j6J/EqjLrPVu/TW6mt/JY9bEtroTFP9vn/RvF+kohvf7nfkqLtOU4/Se4/ktES6bqTvqHdzfyVs/Sc53yu/d/JOuiePoXErh5v4OgW6agO5/uP5Ks3SMR3P8AcfyXO40jON0z/wB38lcxaeqm7p3doYfFqdbE8/6bE93m/g6B8tj9b3H8l8NfEPTHvWiY9bKsfpr9bG/gFsrVigkqaWKokqHNc8OJDWswiz3AWyvyLKM1LQr4nAVcPFSna17ZMyv+0Yf81na4DxVeOVrs2kEc4IPgtLbQquWln8nZNj+DD3YmgEYibDI8wv2qV2HHF5W8u414hhAtlZ5xeI7F6pJuxBLD1I01UayZthERZEIREQBERAEREAREQBERAEREAREQBR+mtJMpoJKiU2ZG0uPOeZo6SbAdJV+Vp3bFrDjlbQRnix2fJb0nkXa09QN+tw5l5KVlcmw9F1aij58jBa6ufUzSVMvnvcXHo5A0dAAA7FUhareFivIwqcmdphKWzEqlhFrgi4uPnC9rjnzB7l5WU6tUIrKeel/Sx/DwnrFns6jxe03WLuH/AK5kayuWKdXblKD1i8+TzT8V6prcUnlUXFVXAnIC55gqLl4jyoz2wqoGqkwqs1eMzhoC1bx2fH/D6foa4d0jlpFbj2YTYqFo9V72nvDh7nBTUe0afp6P/nT/AJL7M1dtDn4TSE59V4aPoNDfEFfdmWnfI60NebRTgROPI11/g3d5I+l0Kz1lOKqqHc80v8Ryg6mNeKTvc8q4VPDxju2V9jqYL6sN2ZaxmspAJDeaEiOTncLcR/aN/S0rMlaTuctODhJxe4IiIYhERAEREAREQBERAEREAREQFKeTC1zuYE9wuuYairM0r5nG7nvc43+cb/iul9K/Ey/q3/YK5fpVFVNt0Ws5Pl7klGpfVtsZqoGzAGMyMDgdxBdYX6L2UNGqzTyqtodXFbUHHS6+6sbP0E9rNJ8B5KyCRolaXRYhHLHhLmngz5pOFpuDzrEdf6MQ1swaLNc4SD6bGvd+8T3hZfq5pDy6Jj2vDK6mbZr3A2mZus/na4mx5Qcx049p7T96qSOtpSI3BgfHljie2MNM0LvDkcMlLK2z4mkw0qkMS7RzUbSV+D1jfVNZxztuyuiA1UmIracgOdaVnFaLuPGzsPf2LY2supdJV4paZ7YpcRDnMs6Nzgcw9o3OvyjPnBWD0kX9n1dPVA8LTl12TNGT2Ou1wI9F7QTdvQsi1p0RPTvOktGPJZJx5GM4wdfPGGbntO/nHJvy9grRaZFjqkp14zhLZurJ7m73cXfT5Me8gFKTSaRpy1r3XjqGZuY6wBLXbpGZC7Mjyqx0loWWGQMykEgxRSR8Zszedp8Rye9bB1c1xpK9nktaxjXuywvzikPzHHc7oOfMSpiLU2JsElO178DnmSG5uaV9iLxu32N8wd9yDe5XvVqSyPI9JToStUVnvWqf8lw71o+5ml3AglrhYg2IPIVtDZFVgxTQ8rXsf2OZh/kWsK2J7JHsk89rnNdy3c1xBz7FmWyeqwVbo/8AMid3tcHD3Fyjp5TRtOk49Zg58k/L+rmK6cH94m/WSfbcoqVqmNPi1ROP9WX+I5Q8qxJ5WdJcl9kT2ynSTodJxxjzZg6N457Mc9p7C33ldBLm7Z78q0n6x38KRdIq1T0ORxy/Mv8A7UIiLMpBERAEREAREQBERAEREAREQFnpT4iX9W/7BXL1L+XguotK/Ey/q3/YK5cpPwHgoqptui/1c17klGqzQqMayDUzRwqKuKNwu3FjcOdrRjI7SAO1V7XdjqVUjTpuctEr+RmWjNWBBQtq3PMNQwGoEnqAtyie3lBFgRzkq6gfSaagwyAR1DByee3pafSYb7juPTYqw2qadzFFGchhfLbnObWeDj9Fa6p6l8T2yRPLXNN2uabEf1zKRyUXsrQ01DCVcTR6+crTbbi+C4cbPhu5Noyep0dNo5zqasYZaKUjE5uYadzZIz6Eg5jvtbNXOi9Ov0W9tPK4zUkg4SCVudmE+cwc3rM3g7t+c7q5r9BUs8nrwxjiMOJwHAy3ys6+TD15eCu9N6lwPp3wwnC0nhIWk4mwyHeWE5hjuVtyOUWWaW+LKVeu77GJjZvW2j/kuDW+2TXKxbaS1JpK5gqaSRsbn8bEwYopfaZyHnIsecFSOhtHaSipHwOnYJWH4B9xJiaB5j8Y3cgO8Zb7LWmj62v0TJmx0YJ4zHgmKXqcMict7TfwWyWa9NfSmqhp3SYMpow4YoCdziLcZnzhu5RkbIuO/JmFaliIwUYtThdbLdnZ8M+OmeT5moKl7i9xkvjLnF19+LEcV+m91LaoVXB1kD72AkaD1P4p+0ousqTLI+V1rve5xA3AucSQO9eGuIILTYg3B5iMwq97M6p09um4PK6t5q1iV1vjw1tS3/WkPe8uHuKgJdyybXhwdVulG6RsUo+nCx34rGpF69SCEr4eL/ivsX2zv5VpP1jv4Mi6RXNuzj5WpP1j/wCBIuklZp6HJ476i/29hERSFIIiIAiIgCIiAIiIAiIgCIiAtdKfEy/q3/YK5apd/YPBdS6S+Jk/Vv8AslcsUnJ1DwUVU2vRn6ua9yTjWW7OKgMr4r+kHN7XsNvePesTjWVbPYWvrYQ62WJzQd12scW+/PsUEe0jo69v+LUvpsy+zI3WCR7qiV8gsXSyHjAj9IbAX3gAAdiinrYGnNO1IAqMpYZHYJYJmh7KeZos+Igi7QSCWnpUFV6LiqY3T0LS1zAXS0xOJzByuhdvc0c28dwS2ZjSxDVOO3Gy0undJrKz4cN67yD0Vo2SplZBEAXuNhc2AsLkk8wAKy7RL6ykJhp6ylqQ0kGmExxAjIiPFaxvzG3QVjOrWlfJKmKotcMdxgN5Y4YXW5zYk9izHTOoUMjjVw1NqZ95sLYzI4A8Y8HY53ztlcdKzgssjX4+aVTZqZRayyvd71xWXAyoa00jcEFZ8E58TJSyZvFGO/FJIsCCCM7blJ0goYmPfEadjHi7ywxhrxb0rb9571qeq1shqJDHVU+KnybG4ZVMDWgNDhJ6RNrlpyz6M43TmgTT4ZWPEsEuccrRbF81w9F4zuOjrAz6x66lGl0apWhKTg34p7+Oq4PhlctNIYOGk4L4vE7D7HCHD7rKivIXpVzqo5IlNOuxR00nPA1n/Rkkj8GtUJNuUtO29LG71JZG/tsjcPB6h5dy93lWyVNx4Nr1ZIbN/lWl9t/8CRdIrm/Zr8rUvtyfd5F0grUNDlMd9RcvdhERZlIIiIAiIgCIiAIiIAiIgCIiAttI/FSfq3/ZK5Xo/wAB4LqjSPxUnsP+yVyrRHd1DwUVQ2nRv6ua9yWjUloWtME0U7d8bw63OAcx2gkdqi41ctVZnV0oqULPRqxsnWpvk8nlsTBLSVTW8NEc2OLrEO+aTvDvW61A6M0azhY6qgrI2gOa8xzycFJGL5hwOUjbXFxvU/s80vHUQu0bU2cMLsAd6bDm5l+du8dHUsS1y1XkopL5mJx4jxn9E8zh79/VLLTa/wAjUUPwzlhZytNKyeqnHddPK6WWTTtxtYitZOC8qn4C3BcK7BbdYu5Oi97dFlN6q6zT0I4OeKU07jfNrgYyd7mFwAI5S3tGe+P1HkjbX05mAw47cbcHFpDD+0QprXCu0pRzvc6okMTnucxxGOItJJDC0gtaQDa2W5eR/ceYqzksO0n+FavN7ssnn8mVVOqlBpJnDwvDXOz4SG3GP+ow8vXYq90LqSyGlmo5peGZI7EOLh4M2ADmi5sbgG/QsB0HpeGZwDH+QVbsmywktp5jyNli3MueW1t3QFeaU100pTudTz4GvGWLghcjke23FIPIbKTajq0UY4bFS/JhPg7PVW3p5qy7nlvS0MPq6cxyPidva9zD0lriL+5U1cUFOZ52Rl3Glka0uOeb5AC48+ZuqvkQMcsjXH4N7BYi2IOc8C+eTuJe3XzKA6bbSspa5ersvNn2nzppx6r4Xd/CsP22qIm3Kf0CzFHVs/5Zz+2OSGTwxKBm3IQSfbXf90iQ2Z/K1L7cn3eVdILm/Zj8r0vtS/dpV0grUNDk8b21y92ERFmUwiIgCIiAIiIAiIgCIiAIiIC20h8VJ7D/ALJXKtHvHUPBdV6Q+Kk9h/2SuU6P8B4KOpuNn0dq+a9yViVy1WsSumqqzraHZK0E7mObIxxa4EOa4b2kbitvas6fg0lAYahrDJhtJEdzxbz2Dmz6wexacKzfyCndo5lbTyYKmnDcZjNji4TDZ457O38o5ws6TaeRQ6Wo06kY7V072Ulub0v3X8tedDW3Z5LDeWjDpI9+DfLF1AeeOrPr3q+1c2gRvjFPpDJw4vClt2yWytIPRdzm1upSeqe0aOQCKstHJuEm6N/teofd1blMaxasUlXx5IhiI+NYcLjzHEMndt1MktYM0lerJflYyLdtJLX4ffv45muNeNAsYRWUmB9O+2LgiHNif9HINd45coV3oNv9pUclLJxqilaJIH+k6PcYnHlHN1t5s76XZUSbwVlgd4kjN/2mOF+5ZbqZqizR7XudLjkeAHPw4WtaM8IFz1kleKDcu4kljKUKC2ZXnFrZyzy4+GXfwNO6MY0uAdwl8TbCMAuJLwDa532vb51lOafmc+APxVbmh9g6ZkbYy4Ah1y3e/Ii55j0qNpnny0OpwCfKbxA7iTUXjB6N3YpDSrpDA5+CMRubE0Ma9xdFG18oa6xG58mM4r3y3ZqFbzd1fqwly1a36rjorq29NPVHnUFgfVGI7pIZ4/24T+SxWY5G/wDWayjZ8+2kafpc8d8b1CaxwcHUTx+rNI0dTZHAe6yWyRjUlatOPGMX6yXwVdmHyvS+1L92lXR65x2W/K9L1zfdpV0crMNDmMb2/D3CIizKYREQBERAEREAREQBERAEREBb13xb/Yd9krlKjPgPBdXVvxb/AGHfZK5RouTqHgoqhsujt/Ne5LRK5YraFXLFWZ1tDsn0rOINSHTUUdRSSWkfHZ7C4gS2ecgeQ5DI5XHIsHK2ZT1dRHQ01Vo6zmRMw1EGEHGQeO/C0XvcE3GdnXzWVNJ3uVOkqlSCh1crNytn2Xk7J8917W1ujW7NHYZxDUl0GdnOe0ng7g2cRytvbMclypM6Qr9FuEQk4hGJozkgkb67OjPksedbBpdKaP0wwQzMDJgMmkgSN6YpB5w6O8KNbqfMy9FN/eKR+IxyXaJKJ4GTgCdx3ENuOgZ3k2N8TV1cZtNxrRs1rF6c4vj3Z33O5H6P2qyNFpKVjjzseWfulp8VZawbRKipYYmMbAx2TsLi57hyjHYWB6B2rF9NaJkpZnQS725hw3SNPmvHXzc4KvtWdD+UPe59xBEwyzOHqtBOAH1nWt0ZleOUnkWKWGwkF12yrLNavlZX13FtoeN7p4mROwvMrGtd6jjIA13YbHsU/p+McG97Z3yEincWmBkTcBDhHhwuNgM+KBvIPOofR0kb5sUglabtMYgDcTXY+K0BxFrZAWzuFf6WmaacxsdVOEbwCJBFgjcS82cWkk54rXNt6jysXqu110PDcnvW+2ea88zxqEP8Rpvbd/DeqW0eDBpCoHO4H9tjXH3kqvs+bfSFP0Oce6KRXm2KDDW4vXiYe0FzfABZrseJUxE7YxR40/d/BAbK/lem+u+7SLo1c57KB/i9P9d93kXRinhoc/jfqeAREWZUCIiAIiIAiIgCIiAIiIAiIgKFb8W/2XfZK5Qo+TqC6wq/Mf7LvArk6k3jqUdQ2PR+r5r3JeFXTFaQq7YqrOtw/ZPpWQ6m61OopS1wLoXkY2De07g5o57WuOUdix5bNgqWU9JSSGJr6N8WCoaGNcRI+3wjrjOzg5tunqCyp3vdEHSM4qmqcobW07Wvbc3k7P8AF+1b2NY9S4axorNHSNa93Hs02jkN94I8x9+y+8A5qhqtrDVtkbQ6QikDzcRvc0guwtvhc7c8WBs8dt96x9utDaGrkNA4upXEExuuGm7Riw3zaQdx7DdbFh1mpZqcVIlDWXDXY8uCcfRedzes5HkUyte6yOexMa0KahNbUX2W+1Hu9rPJ7uBrDaHpbh6gMMLojC1zHY7YnkuvfIkYbbs87rL6jRXkegpLC0j2xPkPLeSSMFp6m8XsWM7Qa2nqKqAwPbIcIZI5hBabycUYhkSAXd4W3dNQQmnkZUECLgyHk5YW2336EiruRlUrdXSoKzte7XGz78887eBz/o+qdFIyVtsUb2uF9xLXBwB6Mle11dDwb46eJ44Utc4vcH2DXFzWNwgZXJNzmo+oa0OIYSWgkBxGEuF8iW8l+ZUyoDppU4yak7+q71ddz46MyvZfHi0gz5rJXf8Abw/zKQ22xWmp388T2/svB/mVLZFBese/kbC/vMkdvAqT23s4lM750o72sP4KWK/LNHip26RS/jb0bMF2TfK1P1Tfd3rotc6bJvlan6pvu710WpoaGoxn1PAIiLIqBERAEREAREQBERAEREAREQFGr8x/su8CuTaXzl1lVeY72XeBXJ1NvUdTQ2OA1fh7krCrxis4FPat6JdVzsha617ku34QBcm3L1dKrNXZ1dGahTcpaLUjisy1A1jZHehqrGGUkDFm1jnZFrgfRd7j1m1Ou1Qa+m8roZnSxjFia5oa8BpIcW237r25lby6Do4IYX1ks4knYJGiFkbmRMduxYs3ZEXssoqUXcr4mrh8RSdN3edrJfiTWem63+3kjrXs4lYXS0XwjDnwZPHZ0NPpj39axTV+rkpqkRujJEhEM0LmkcI1zrWLDyi9x/5W0qHTroKOGWPFWQsLmSSxgiSNjbYXOjdmSBk4dAKuW610ErRI2oiB+eQxzex1j3KXZjfLI0bxddQlCpHbWavo/H75pM1LrRoU0VTgFyzJ8ZPq4sgTykEW7udZ9tY0qfJ4IWnKY43fOawCw/acD9ELEdoenIqqaMQHEyJjm4+R5c4E2vvAwjPpKr63Tmaj0dNe9onxOPzonMafArF2V0i7RhKpKhOpqr352uvHK5iwQoEKhN4bL2NU3/2JfYjH7zj4tXvbcP7vAf8AVcO+In8FMbKqTBQh53yyOf2CzB9n3qI23n+7wD/Wcf8AtO/NWbWpnK1am30i3328lb2NfbJz/i1P9d93kXRi5z2T/K1P9d93kXRizhoU8Z9RcgiIsioEREAREQBERAEREAREQBERAUarzHey7wXJ1NvXWVV5jvZPguTafeo6mhsMBq/D3JWBZfs7qxHXRYtz7s/6jcveAO1YhAr+B5aQ5psQQQRyEG4Kr3s7nUxpqrRlTe9NenyZJp11Vo+eanikcyKQucAPNkjde1rg2IHFJFjkpvVOOm0lTNo6kkSwX4NzTZ3Bn1bixtfCQQdzSp2qo49MUTJAQJWjI+pIBZ7D80/kVqlxmpJ/Silid1Fp/EEdhBWbWw77ihSf/LpOHZrReb33WV3xTzT/ANfJNcpqmimhip2yQQwNIieLHhXOdie9zvNcTlxHc27NWL6eLSbXPhY2KsYC50beLHVNG98YOTH845b9ozrVvW+mr4/J6tkbZDxSx4HBzZb2X3Hfxd45Lq4p9SKSnnFTCJGubfCwvuxpIIJsRi3E5Xss9m+mhrp4p0lsVIuNRaNfq58U9dXno1oaQAIyIIINiCLEEchB3LKIzwmiiPSp6lrupk0Rb9sBV9plAyKqD2WBlYHvaOR2ItLvpWv2FUtSoeFZWU3+ZTPc0fPheyRnvuo2rSsbKFWMqMa2lmpetn6NmPhOUdfegU1qdo/h6yCO1xiDneyzjHwA7Vgldm0qTVOLk92fkbt1foeApoYfUjY0+1hGI991gW3B/wAFTt+fIe5rR+K2etRbcJryU8fNHI4/Sc0D7BVqfZOMwV5YhN979GYhsn+Vqf677vIujVzjsn+V6f677tIujl7DQxxn1PD5CIiyKoREQBERAEREAREQBERAEREBSqfMd7J8FyZT711nU+Y72T4LkyAcZYTNhgNX4e5LQK8YrKBXjFUlqdbhuyZLqXrKaObjXML7B7ebmcBzj3jsWydY9W6fSMTZGvAfhvFM3PI5gO9ZvQtJlZJqjrhJRHA8GSEm5bfjMJ3ujvkOct3HoUlOa7MtCj0jgZyksRh3aa9f7+6yITWDV+ejfgnjsD5rhmyT2Xfgc19pdaq2JuCOqkDRuDjjA6sYNlvSiraWuhJaWTRuyc1wBt0PYdx61iOnNmtI84oXPgPMDjZ2NdmOwrPq2s4s1i6ShUWxiIZru9noanqauSV5kleXvO9zjcn8h0LN9kdIX1b324rYXA9bi0Ae53crqk2VOJ41WMPRGcXvdZZgaen0RRvdHyC93G7ppLWbc9dhbcAkYNO7MsRjacqLpUs3KyWT49/kaUnbZzgOQuHcbLY+yDRd+Fq3Dmib15Of/IO9a3bdzue7tw9Ik8nWVv8A1X0X5LSxQcrW3f0vdm4991jSV5XLvTNbq8P1e+WXgtfjlcl1o3bBVY60tH6ONjO0gvP2wt5Fc364VnDVVRLe4dI+3S1r7N/dAUtR5I03RkLzlLgvu0VNk/ytTfXfdpF0cucdk/ytTfXfdpF0csoaEGM+p4BERZFQIiIAiIgCIiAIiIAiIgCIiApzi7SOg+C5MiFnEcxI7iutitQa57L3cK+pojxXkvdFa+BxzOG2dic7Z2ueRYzTehbwlWNOX4jXdOVesKqv1fqoyQYg62+zrEdYdYqiWSNydBKPq3Ed4FlVlBnT4TG0Nm22vM9lUpF5fVNG/LrBHiqTqyP12968SZddanJZSXmXVHXSwv4SGRzHD0mEg9R5x0HJZXSbTapowzRxzfOsY3dpbke5YOalnrjvCpvqGesO9ZRbWhr8TTo1e2k/v56mzGbVXAcWkF+mQ27gxYpp/WOorHh8z8m+a1osxl+UDlPSc1jzZ2esO9VBUM9dveF7KUnqYYXD4elLaiknxv8ALM32ZaG4eqErhdkFn9Bff4Md4xfRW61g+pNTSUdK2N0zOEd8JIbjNzhu7BYdinn610Y/TtPVmp6cbI0PSGJ6+u2tFkvnxdyprTpDyekml5Qw4elzuK0d5C5xqzYdi2ntK1iE8MdPSskku/G8tY61mNyBJyzLr/RWvodW6uc4GQ5nkviI7G3t2rCabkXMDVpUcNJykk2/Rae5W2RNJ0tBYbhMT0DgHi/eR3ro5YDs21D/ALPxTzOx1Egw5ebC29y0c5Nhc9AWfKSKsjWYiopzugiIsiAIiIAiIgCIiAIiIAiIgCIiAKN0pXSRglkeJSSIDTmsmsEpnDp4C1oBGNrSSM8sQGZG/vXyl0jFJ5k7Cea4uOy91t2WmY7zmNPWAo6r1XopfjKSJ3W0IDXfAl3qnvVGTR/zGH+ukLOnahaP9GDB7D3s8CqZ1ApPRfUN6qiT8Sh5Y19Lo8f5MZ/Z/JWpoAP/AM7P3fyWxnbPqfkqKkfW38Wr4dnkH/FVP7bP9iHpr1tJ/wAvH3N/JVBSn/Ij/d/JZ+NnsH/E1P7bP9i9DZ7S8stSfriPABBmYQyldvwRj+upVA0tFy5jf661m7dn1DyiZ3tTyn+ZVo9RNGg38ijcRyvBee9xKA1nUaahbxRLjd6sYxO7hu7Vk+pWmKkMDRT4QSSbjM3O9x5Ss7pdDU0fxdPG3qY0fgr1rQNwt1IClSyOcLubYquiIAiIgCIiAIiIAiIgCIiAIiIAiIgCIiAIiIAiIgCIiAIiIAiIgCIiAIiIAiIgCIiAIiIAiIgP/9k=',
        name: 'Coca Cola Can',
        nameDetail: '2L, Price',
        price: 4.99,
        category: "Beverages",
        quantity: 1

    },
    {
        img: 'https://m.media-amazon.com/images/I/61Q7SR0r9XL._SL1500_.jpg',
        name: 'Pepsi Can ',
        nameDetail: '330ml, Price',
        price: 4.99,
        category: "Beverages",
        quantity: 1

    },
    {
        img: 'data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEAAkGBxISEhUQEBAVFRUWFRUVFhUVFRUVFxAYFREWFxgVFxUYHSggGB4lHhUVIjEhJyorLi4uFx8zODMsOSgtLisBCgoKDg0OGxAQGyslICYtLS0tLy0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLf/AABEIAOEA4QMBIgACEQEDEQH/xAAcAAEAAQUBAQAAAAAAAAAAAAAABQMEBgcIAgH/xABOEAABAwICBAkGCgcGBgMAAAABAAIDBBESIQUGBzETIkFRYXGBkbEUMkJScqEjMzVigoOytMHRQ3OSorPC8BUkJVNj0lRkk6Ph8RY0RP/EABoBAQACAwEAAAAAAAAAAAAAAAADBAIFBgH/xAA0EQACAQIDBAkCBwADAAAAAAAAAQIDEQQhMRJBUXEFEzJhgZGhwdEzsSIjQlJi4fAUFST/2gAMAwEAAhEDEQA/AN4oiIAiIgCIiAIi+FAUJquNmT5GN9pwHiVSGlIDulYeo38FpTaBO6DSk5jwuLxE8kg8UmIDD+6D2q3g1tqRuMY+gf8AcsHUSLlHAV6yTgsuaN7iujPpe535L6axnre4/ktIf/L6v12j6J/EqjLrPVu/TW6mt/JY9bEtroTFP9vn/RvF+kohvf7nfkqLtOU4/Se4/ktES6bqTvqHdzfyVs/Sc53yu/d/JOuiePoXErh5v4OgW6agO5/uP5Ks3SMR3P8AcfyXO40jON0z/wB38lcxaeqm7p3doYfFqdbE8/6bE93m/g6B8tj9b3H8l8NfEPTHvWiY9bKsfpr9bG/gFsrVigkqaWKokqHNc8OJDWswiz3AWyvyLKM1LQr4nAVcPFSna17ZMyv+0Yf81na4DxVeOVrs2kEc4IPgtLbQquWln8nZNj+DD3YmgEYibDI8wv2qV2HHF5W8u414hhAtlZ5xeI7F6pJuxBLD1I01UayZthERZEIREQBERAEREAREQBERAEREAREQBR+mtJMpoJKiU2ZG0uPOeZo6SbAdJV+Vp3bFrDjlbQRnix2fJb0nkXa09QN+tw5l5KVlcmw9F1aij58jBa6ufUzSVMvnvcXHo5A0dAAA7FUhareFivIwqcmdphKWzEqlhFrgi4uPnC9rjnzB7l5WU6tUIrKeel/Sx/DwnrFns6jxe03WLuH/AK5kayuWKdXblKD1i8+TzT8V6prcUnlUXFVXAnIC55gqLl4jyoz2wqoGqkwqs1eMzhoC1bx2fH/D6foa4d0jlpFbj2YTYqFo9V72nvDh7nBTUe0afp6P/nT/AJL7M1dtDn4TSE59V4aPoNDfEFfdmWnfI60NebRTgROPI11/g3d5I+l0Kz1lOKqqHc80v8Ryg6mNeKTvc8q4VPDxju2V9jqYL6sN2ZaxmspAJDeaEiOTncLcR/aN/S0rMlaTuctODhJxe4IiIYhERAEREAREQBERAEREAREQFKeTC1zuYE9wuuYairM0r5nG7nvc43+cb/iul9K/Ey/q3/YK5fpVFVNt0Ws5Pl7klGpfVtsZqoGzAGMyMDgdxBdYX6L2UNGqzTyqtodXFbUHHS6+6sbP0E9rNJ8B5KyCRolaXRYhHLHhLmngz5pOFpuDzrEdf6MQ1swaLNc4SD6bGvd+8T3hZfq5pDy6Jj2vDK6mbZr3A2mZus/na4mx5Qcx049p7T96qSOtpSI3BgfHljie2MNM0LvDkcMlLK2z4mkw0qkMS7RzUbSV+D1jfVNZxztuyuiA1UmIracgOdaVnFaLuPGzsPf2LY2supdJV4paZ7YpcRDnMs6Nzgcw9o3OvyjPnBWD0kX9n1dPVA8LTl12TNGT2Ou1wI9F7QTdvQsi1p0RPTvOktGPJZJx5GM4wdfPGGbntO/nHJvy9grRaZFjqkp14zhLZurJ7m73cXfT5Me8gFKTSaRpy1r3XjqGZuY6wBLXbpGZC7Mjyqx0loWWGQMykEgxRSR8Zszedp8Rye9bB1c1xpK9nktaxjXuywvzikPzHHc7oOfMSpiLU2JsElO178DnmSG5uaV9iLxu32N8wd9yDe5XvVqSyPI9JToStUVnvWqf8lw71o+5ml3AglrhYg2IPIVtDZFVgxTQ8rXsf2OZh/kWsK2J7JHsk89rnNdy3c1xBz7FmWyeqwVbo/8AMid3tcHD3Fyjp5TRtOk49Zg58k/L+rmK6cH94m/WSfbcoqVqmNPi1ROP9WX+I5Q8qxJ5WdJcl9kT2ynSTodJxxjzZg6N457Mc9p7C33ldBLm7Z78q0n6x38KRdIq1T0ORxy/Mv8A7UIiLMpBERAEREAREQBERAEREAREQFnpT4iX9W/7BXL1L+XguotK/Ey/q3/YK5cpPwHgoqptui/1c17klGqzQqMayDUzRwqKuKNwu3FjcOdrRjI7SAO1V7XdjqVUjTpuctEr+RmWjNWBBQtq3PMNQwGoEnqAtyie3lBFgRzkq6gfSaagwyAR1DByee3pafSYb7juPTYqw2qadzFFGchhfLbnObWeDj9Fa6p6l8T2yRPLXNN2uabEf1zKRyUXsrQ01DCVcTR6+crTbbi+C4cbPhu5Noyep0dNo5zqasYZaKUjE5uYadzZIz6Eg5jvtbNXOi9Ov0W9tPK4zUkg4SCVudmE+cwc3rM3g7t+c7q5r9BUs8nrwxjiMOJwHAy3ys6+TD15eCu9N6lwPp3wwnC0nhIWk4mwyHeWE5hjuVtyOUWWaW+LKVeu77GJjZvW2j/kuDW+2TXKxbaS1JpK5gqaSRsbn8bEwYopfaZyHnIsecFSOhtHaSipHwOnYJWH4B9xJiaB5j8Y3cgO8Zb7LWmj62v0TJmx0YJ4zHgmKXqcMict7TfwWyWa9NfSmqhp3SYMpow4YoCdziLcZnzhu5RkbIuO/JmFaliIwUYtThdbLdnZ8M+OmeT5moKl7i9xkvjLnF19+LEcV+m91LaoVXB1kD72AkaD1P4p+0ousqTLI+V1rve5xA3AucSQO9eGuIILTYg3B5iMwq97M6p09um4PK6t5q1iV1vjw1tS3/WkPe8uHuKgJdyybXhwdVulG6RsUo+nCx34rGpF69SCEr4eL/ivsX2zv5VpP1jv4Mi6RXNuzj5WpP1j/wCBIuklZp6HJ476i/29hERSFIIiIAiIgCIiAIiIAiIgCIiAtdKfEy/q3/YK5apd/YPBdS6S+Jk/Vv8AslcsUnJ1DwUVU2vRn6ua9yTjWW7OKgMr4r+kHN7XsNvePesTjWVbPYWvrYQ62WJzQd12scW+/PsUEe0jo69v+LUvpsy+zI3WCR7qiV8gsXSyHjAj9IbAX3gAAdiinrYGnNO1IAqMpYZHYJYJmh7KeZos+Igi7QSCWnpUFV6LiqY3T0LS1zAXS0xOJzByuhdvc0c28dwS2ZjSxDVOO3Gy0undJrKz4cN67yD0Vo2SplZBEAXuNhc2AsLkk8wAKy7RL6ykJhp6ylqQ0kGmExxAjIiPFaxvzG3QVjOrWlfJKmKotcMdxgN5Y4YXW5zYk9izHTOoUMjjVw1NqZ95sLYzI4A8Y8HY53ztlcdKzgssjX4+aVTZqZRayyvd71xWXAyoa00jcEFZ8E58TJSyZvFGO/FJIsCCCM7blJ0goYmPfEadjHi7ywxhrxb0rb9571qeq1shqJDHVU+KnybG4ZVMDWgNDhJ6RNrlpyz6M43TmgTT4ZWPEsEuccrRbF81w9F4zuOjrAz6x66lGl0apWhKTg34p7+Oq4PhlctNIYOGk4L4vE7D7HCHD7rKivIXpVzqo5IlNOuxR00nPA1n/Rkkj8GtUJNuUtO29LG71JZG/tsjcPB6h5dy93lWyVNx4Nr1ZIbN/lWl9t/8CRdIrm/Zr8rUvtyfd5F0grUNDlMd9RcvdhERZlIIiIAiIgCIiAIiIAiIgCIiAttI/FSfq3/ZK5Xo/wAB4LqjSPxUnsP+yVyrRHd1DwUVQ2nRv6ua9yWjUloWtME0U7d8bw63OAcx2gkdqi41ctVZnV0oqULPRqxsnWpvk8nlsTBLSVTW8NEc2OLrEO+aTvDvW61A6M0azhY6qgrI2gOa8xzycFJGL5hwOUjbXFxvU/s80vHUQu0bU2cMLsAd6bDm5l+du8dHUsS1y1XkopL5mJx4jxn9E8zh79/VLLTa/wAjUUPwzlhZytNKyeqnHddPK6WWTTtxtYitZOC8qn4C3BcK7BbdYu5Oi97dFlN6q6zT0I4OeKU07jfNrgYyd7mFwAI5S3tGe+P1HkjbX05mAw47cbcHFpDD+0QprXCu0pRzvc6okMTnucxxGOItJJDC0gtaQDa2W5eR/ceYqzksO0n+FavN7ssnn8mVVOqlBpJnDwvDXOz4SG3GP+ow8vXYq90LqSyGlmo5peGZI7EOLh4M2ADmi5sbgG/QsB0HpeGZwDH+QVbsmywktp5jyNli3MueW1t3QFeaU100pTudTz4GvGWLghcjke23FIPIbKTajq0UY4bFS/JhPg7PVW3p5qy7nlvS0MPq6cxyPidva9zD0lriL+5U1cUFOZ52Rl3Glka0uOeb5AC48+ZuqvkQMcsjXH4N7BYi2IOc8C+eTuJe3XzKA6bbSspa5ersvNn2nzppx6r4Xd/CsP22qIm3Kf0CzFHVs/5Zz+2OSGTwxKBm3IQSfbXf90iQ2Z/K1L7cn3eVdILm/Zj8r0vtS/dpV0grUNDk8b21y92ERFmUwiIgCIiAIiIAiIgCIiAIiIC20h8VJ7D/ALJXKtHvHUPBdV6Q+Kk9h/2SuU6P8B4KOpuNn0dq+a9yViVy1WsSumqqzraHZK0E7mObIxxa4EOa4b2kbitvas6fg0lAYahrDJhtJEdzxbz2Dmz6wexacKzfyCndo5lbTyYKmnDcZjNji4TDZ457O38o5ws6TaeRQ6Wo06kY7V072Ulub0v3X8tedDW3Z5LDeWjDpI9+DfLF1AeeOrPr3q+1c2gRvjFPpDJw4vClt2yWytIPRdzm1upSeqe0aOQCKstHJuEm6N/teofd1blMaxasUlXx5IhiI+NYcLjzHEMndt1MktYM0lerJflYyLdtJLX4ffv45muNeNAsYRWUmB9O+2LgiHNif9HINd45coV3oNv9pUclLJxqilaJIH+k6PcYnHlHN1t5s76XZUSbwVlgd4kjN/2mOF+5ZbqZqizR7XudLjkeAHPw4WtaM8IFz1kleKDcu4kljKUKC2ZXnFrZyzy4+GXfwNO6MY0uAdwl8TbCMAuJLwDa532vb51lOafmc+APxVbmh9g6ZkbYy4Ah1y3e/Ii55j0qNpnny0OpwCfKbxA7iTUXjB6N3YpDSrpDA5+CMRubE0Ma9xdFG18oa6xG58mM4r3y3ZqFbzd1fqwly1a36rjorq29NPVHnUFgfVGI7pIZ4/24T+SxWY5G/wDWayjZ8+2kafpc8d8b1CaxwcHUTx+rNI0dTZHAe6yWyRjUlatOPGMX6yXwVdmHyvS+1L92lXR65x2W/K9L1zfdpV0crMNDmMb2/D3CIizKYREQBERAEREAREQBERAEREBb13xb/Yd9krlKjPgPBdXVvxb/AGHfZK5RouTqHgoqhsujt/Ne5LRK5YraFXLFWZ1tDsn0rOINSHTUUdRSSWkfHZ7C4gS2ecgeQ5DI5XHIsHK2ZT1dRHQ01Vo6zmRMw1EGEHGQeO/C0XvcE3GdnXzWVNJ3uVOkqlSCh1crNytn2Xk7J8917W1ujW7NHYZxDUl0GdnOe0ng7g2cRytvbMclypM6Qr9FuEQk4hGJozkgkb67OjPksedbBpdKaP0wwQzMDJgMmkgSN6YpB5w6O8KNbqfMy9FN/eKR+IxyXaJKJ4GTgCdx3ENuOgZ3k2N8TV1cZtNxrRs1rF6c4vj3Z33O5H6P2qyNFpKVjjzseWfulp8VZawbRKipYYmMbAx2TsLi57hyjHYWB6B2rF9NaJkpZnQS725hw3SNPmvHXzc4KvtWdD+UPe59xBEwyzOHqtBOAH1nWt0ZleOUnkWKWGwkF12yrLNavlZX13FtoeN7p4mROwvMrGtd6jjIA13YbHsU/p+McG97Z3yEincWmBkTcBDhHhwuNgM+KBvIPOofR0kb5sUglabtMYgDcTXY+K0BxFrZAWzuFf6WmaacxsdVOEbwCJBFgjcS82cWkk54rXNt6jysXqu110PDcnvW+2ea88zxqEP8Rpvbd/DeqW0eDBpCoHO4H9tjXH3kqvs+bfSFP0Oce6KRXm2KDDW4vXiYe0FzfABZrseJUxE7YxR40/d/BAbK/lem+u+7SLo1c57KB/i9P9d93kXRinhoc/jfqeAREWZUCIiAIiIAiIgCIiAIiIAiIgKFb8W/2XfZK5Qo+TqC6wq/Mf7LvArk6k3jqUdQ2PR+r5r3JeFXTFaQq7YqrOtw/ZPpWQ6m61OopS1wLoXkY2De07g5o57WuOUdix5bNgqWU9JSSGJr6N8WCoaGNcRI+3wjrjOzg5tunqCyp3vdEHSM4qmqcobW07Wvbc3k7P8AF+1b2NY9S4axorNHSNa93Hs02jkN94I8x9+y+8A5qhqtrDVtkbQ6QikDzcRvc0guwtvhc7c8WBs8dt96x9utDaGrkNA4upXEExuuGm7Riw3zaQdx7DdbFh1mpZqcVIlDWXDXY8uCcfRedzes5HkUyte6yOexMa0KahNbUX2W+1Hu9rPJ7uBrDaHpbh6gMMLojC1zHY7YnkuvfIkYbbs87rL6jRXkegpLC0j2xPkPLeSSMFp6m8XsWM7Qa2nqKqAwPbIcIZI5hBabycUYhkSAXd4W3dNQQmnkZUECLgyHk5YW2336EiruRlUrdXSoKzte7XGz78887eBz/o+qdFIyVtsUb2uF9xLXBwB6Mle11dDwb46eJ44Utc4vcH2DXFzWNwgZXJNzmo+oa0OIYSWgkBxGEuF8iW8l+ZUyoDppU4yak7+q71ddz46MyvZfHi0gz5rJXf8Abw/zKQ22xWmp388T2/svB/mVLZFBese/kbC/vMkdvAqT23s4lM750o72sP4KWK/LNHip26RS/jb0bMF2TfK1P1Tfd3rotc6bJvlan6pvu710WpoaGoxn1PAIiLIqBERAEREAREQBERAEREAREQFGr8x/su8CuTaXzl1lVeY72XeBXJ1NvUdTQ2OA1fh7krCrxis4FPat6JdVzsha617ku34QBcm3L1dKrNXZ1dGahTcpaLUjisy1A1jZHehqrGGUkDFm1jnZFrgfRd7j1m1Ou1Qa+m8roZnSxjFia5oa8BpIcW237r25lby6Do4IYX1ks4knYJGiFkbmRMduxYs3ZEXssoqUXcr4mrh8RSdN3edrJfiTWem63+3kjrXs4lYXS0XwjDnwZPHZ0NPpj39axTV+rkpqkRujJEhEM0LmkcI1zrWLDyi9x/5W0qHTroKOGWPFWQsLmSSxgiSNjbYXOjdmSBk4dAKuW610ErRI2oiB+eQxzex1j3KXZjfLI0bxddQlCpHbWavo/H75pM1LrRoU0VTgFyzJ8ZPq4sgTykEW7udZ9tY0qfJ4IWnKY43fOawCw/acD9ELEdoenIqqaMQHEyJjm4+R5c4E2vvAwjPpKr63Tmaj0dNe9onxOPzonMafArF2V0i7RhKpKhOpqr352uvHK5iwQoEKhN4bL2NU3/2JfYjH7zj4tXvbcP7vAf8AVcO+In8FMbKqTBQh53yyOf2CzB9n3qI23n+7wD/Wcf8AtO/NWbWpnK1am30i3328lb2NfbJz/i1P9d93kXRi5z2T/K1P9d93kXRizhoU8Z9RcgiIsioEREAREQBERAEREAREQBERAUarzHey7wXJ1NvXWVV5jvZPguTafeo6mhsMBq/D3JWBZfs7qxHXRYtz7s/6jcveAO1YhAr+B5aQ5psQQQRyEG4Kr3s7nUxpqrRlTe9NenyZJp11Vo+eanikcyKQucAPNkjde1rg2IHFJFjkpvVOOm0lTNo6kkSwX4NzTZ3Bn1bixtfCQQdzSp2qo49MUTJAQJWjI+pIBZ7D80/kVqlxmpJ/Silid1Fp/EEdhBWbWw77ihSf/LpOHZrReb33WV3xTzT/ANfJNcpqmimhip2yQQwNIieLHhXOdie9zvNcTlxHc27NWL6eLSbXPhY2KsYC50beLHVNG98YOTH845b9ozrVvW+mr4/J6tkbZDxSx4HBzZb2X3Hfxd45Lq4p9SKSnnFTCJGubfCwvuxpIIJsRi3E5Xss9m+mhrp4p0lsVIuNRaNfq58U9dXno1oaQAIyIIINiCLEEchB3LKIzwmiiPSp6lrupk0Rb9sBV9plAyKqD2WBlYHvaOR2ItLvpWv2FUtSoeFZWU3+ZTPc0fPheyRnvuo2rSsbKFWMqMa2lmpetn6NmPhOUdfegU1qdo/h6yCO1xiDneyzjHwA7Vgldm0qTVOLk92fkbt1foeApoYfUjY0+1hGI991gW3B/wAFTt+fIe5rR+K2etRbcJryU8fNHI4/Sc0D7BVqfZOMwV5YhN979GYhsn+Vqf677vIujVzjsn+V6f677tIujl7DQxxn1PD5CIiyKoREQBERAEREAREQBERAEREBSqfMd7J8FyZT711nU+Y72T4LkyAcZYTNhgNX4e5LQK8YrKBXjFUlqdbhuyZLqXrKaObjXML7B7ebmcBzj3jsWydY9W6fSMTZGvAfhvFM3PI5gO9ZvQtJlZJqjrhJRHA8GSEm5bfjMJ3ujvkOct3HoUlOa7MtCj0jgZyksRh3aa9f7+6yITWDV+ejfgnjsD5rhmyT2Xfgc19pdaq2JuCOqkDRuDjjA6sYNlvSiraWuhJaWTRuyc1wBt0PYdx61iOnNmtI84oXPgPMDjZ2NdmOwrPq2s4s1i6ShUWxiIZru9noanqauSV5kleXvO9zjcn8h0LN9kdIX1b324rYXA9bi0Ae53crqk2VOJ41WMPRGcXvdZZgaen0RRvdHyC93G7ppLWbc9dhbcAkYNO7MsRjacqLpUs3KyWT49/kaUnbZzgOQuHcbLY+yDRd+Fq3Dmib15Of/IO9a3bdzue7tw9Ik8nWVv8A1X0X5LSxQcrW3f0vdm4991jSV5XLvTNbq8P1e+WXgtfjlcl1o3bBVY60tH6ONjO0gvP2wt5Fc364VnDVVRLe4dI+3S1r7N/dAUtR5I03RkLzlLgvu0VNk/ytTfXfdpF0cucdk/ytTfXfdpF0csoaEGM+p4BERZFQIiIAiIgCIiAIiIAiIgCIiApzi7SOg+C5MiFnEcxI7iutitQa57L3cK+pojxXkvdFa+BxzOG2dic7Z2ueRYzTehbwlWNOX4jXdOVesKqv1fqoyQYg62+zrEdYdYqiWSNydBKPq3Ed4FlVlBnT4TG0Nm22vM9lUpF5fVNG/LrBHiqTqyP12968SZddanJZSXmXVHXSwv4SGRzHD0mEg9R5x0HJZXSbTapowzRxzfOsY3dpbke5YOalnrjvCpvqGesO9ZRbWhr8TTo1e2k/v56mzGbVXAcWkF+mQ27gxYpp/WOorHh8z8m+a1osxl+UDlPSc1jzZ2esO9VBUM9dveF7KUnqYYXD4elLaiknxv8ALM32ZaG4eqErhdkFn9Bff4Md4xfRW61g+pNTSUdK2N0zOEd8JIbjNzhu7BYdinn610Y/TtPVmp6cbI0PSGJ6+u2tFkvnxdyprTpDyekml5Qw4elzuK0d5C5xqzYdi2ntK1iE8MdPSskku/G8tY61mNyBJyzLr/RWvodW6uc4GQ5nkviI7G3t2rCabkXMDVpUcNJykk2/Rae5W2RNJ0tBYbhMT0DgHi/eR3ro5YDs21D/ALPxTzOx1Egw5ebC29y0c5Nhc9AWfKSKsjWYiopzugiIsiAIiIAiIgCIiAIiIAiIgCIiAKN0pXSRglkeJSSIDTmsmsEpnDp4C1oBGNrSSM8sQGZG/vXyl0jFJ5k7Cea4uOy91t2WmY7zmNPWAo6r1XopfjKSJ3W0IDXfAl3qnvVGTR/zGH+ukLOnahaP9GDB7D3s8CqZ1ApPRfUN6qiT8Sh5Y19Lo8f5MZ/Z/JWpoAP/AM7P3fyWxnbPqfkqKkfW38Wr4dnkH/FVP7bP9iHpr1tJ/wAvH3N/JVBSn/Ij/d/JZ+NnsH/E1P7bP9i9DZ7S8stSfriPABBmYQyldvwRj+upVA0tFy5jf661m7dn1DyiZ3tTyn+ZVo9RNGg38ijcRyvBee9xKA1nUaahbxRLjd6sYxO7hu7Vk+pWmKkMDRT4QSSbjM3O9x5Ss7pdDU0fxdPG3qY0fgr1rQNwt1IClSyOcLubYquiIAiIgCIiAIiIAiIgCIiAIiIAiIgCIiAIiIAiIgCIiAIiIAiIgCIiAIiIAiIgCIiAIiIAiIgP/9k=',
        name: 'Coca Cola Can',
        nameDetail: '2L, Price',
        price: 4.99,
        category: "Cooking Oil& Ghee",
        quantity: 1

    },
    {
        img: 'https://m.media-amazon.com/images/I/81TAT5STa2S._SL1500_.jpg',
        name: 'Coca Cola Can',
        nameDetail: '2L, Price',
        price: 4.99,
        category: "Cooking Oil& Ghee",
        quantity: 1

    },
    {
        img: tomato,
        name: 'Toamto',
        nameDetail: '1kg, Price',
        price: 4.99,
        category: "Fresh Fruits& Vegetable",
        quantity: 1

    },
    {
        img: strawberry,
        name: 'strawberry',
        nameDetail: '1kg, Price',
        price: 4.99,
        category: "Fresh Fruits& Vegetable",
        quantity: 1

    },
    {
        img: orange,
        name: 'orange',
        nameDetail: '1kg, Price',
        price: 4.99,
        category: "Fresh Fruits& Vegetable",
        quantity: 1

    },
    {
        img: kiwi,
        name: 'kiwi',
        nameDetail: '1kg, Price',
        price: 4.99,
        category: "Fresh Fruits& Vegetable",
        quantity: 1

    },
    {
        img:'https://solidstarts.com/wp-content/uploads/when-can-babies-eat-eggs.jpg',
        name: 'Egg',
        nameDetail: '6pieces, Price',
        price: 5.99,
        category: "Dairy & Eggs",
        quantity: 1
    },
    {
        img:'https://media.wired.co.uk/photos/606d9c01f19707fe1aef2e63/4:3/w_2664,h_1998,c_limit/egg-insta.jpg',
        name: 'Brown Egg',
        nameDetail: '6pieces, Price',
        price: 5.99,
        category: "Dairy & Eggs",
        quantity: 1
    },
    {
        img:'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTWZQGwngLLDGJGaFi80qzhYf2l3gVO4nwAOQ&usqp=CAU',
        name: 'sushi',
        nameDetail: '1kg, Price',
        price: 5.99,
        category: "Meat & Fish",
        quantity: 1
    },
    {
        img:'https://image.shutterstock.com/image-photo/assortment-meat-seafood-beef-chicken-260nw-1410046670.jpg',
        name: 'sushi',
        nameDetail: '1kg, Price',
        price: 5.99,
        category: "Meat & Fish",
        quantity: 1
    },
    {
        img:'data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEAAoHCBUVFBcVFRYXGBcXHCIZGhoaHBkaGBoaGhkZIB4gGiEeICwjHR0qIBoZJDYkKy0vMzM0GiI4PjgyPSwyMy8BCwsLDw4PHhISHjIqIyo6MjIyOjo0MjIyMjQ0MjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMv/AABEIAKcBLQMBIgACEQEDEQH/xAAbAAACAwEBAQAAAAAAAAAAAAAEBQIDBgABB//EAD8QAAECBAMFBQcDAwMDBQAAAAECEQADITEEEkEFIlFhcQYTgZGhMkJSscHR8BRi4SNygjOS8QcVUxZDorLS/8QAGQEAAwEBAQAAAAAAAAAAAAAAAQIDBAAF/8QAKREAAgICAgIBBAEFAQAAAAAAAAECEQMhEjFBURMEImFxMhRSgZHxQv/aAAwDAQACEQMRAD8AAw2EJB1zKIo/vKYjqwAjWIkIlpEs0KqzTl9kMNdHCT6U4dKwKZXdoUxUxUsEszBxmaxKiDf4QHYwr2ltErEwAFqBT/8AuKsw/awUP8njw5NydI9hbFG3NrmYoJQMqUgABq2+enGIIkJlMFI7ycplBBqlD+zmHvrLg5bVDvURZIkpkvMmDPMNUIPxGoUsa3cJ1dzQgF/s3BCWj9RMLzioqSkgkvZzrqo8d7rDaS0M2AypJlDvZoMycSMoUUpQkJoHKt0O1hoABFCUYjEzGSxKvhyMAOYFh0EHTFTMRMfvL0dgNNCLJZzQuwia9tdygokKzZgyphAJU92eydAGc16wL2DfjsYTlSMGnKwmzlJoQXSk11JpUmM1j9uzVLKsxzGjkhQA4JAGRvCF89RJbU34/wAdIhKklRAAqfyvAQ37GjjS2yK1qVc0ubAeQpDzZuASmX3swBkHMkH3lAJAf9oLk9AI92ZsoLUAaISMyybkflB4nSK9sY8zFU9lNEgVDjXpdmvXnCt2F70gDaGLVMWVKVU6AU8X5QAvqYuU/GIFMFDJFBERIi8pjwphrDQORHhEXKTFZEGwFZEQIi4iIEQUwUVGPDEyI9RLJIADklh1MNYtFJEQVG82V2ZShIVMSFrPFykU0H39IYrwSWIyBnYDIA3VjQcDWxiD+pjekNwPl5jwxqNq7Ml1YZFcB14DSM3OlFJZQYxbHkU+icoNFJiBiwiIERZCkYiREwkksKmNLsnYNMy2fnYdOJhMmSMFsMMbm9Gdl4RarJ86RKZs6YA+Xyjbp2ekA71QNA/q3pETIB4HX5Rk/q3fRf4I12fP1AihiEavbOzUqTmT7QtzbSMqRGzFkWRWZskHF0RMdHND3YPZteIIUdyX8Rur+wa9bdbRSUoxVyYiTbpCGPHj6vh9lSMOl0SwWuo7yz4n6RPa+zZE1PsJL8qjmDcRk/rY31or8Drs+SRzw023slUhbO6FeyfoecKo2xkpq0QlFp0z62vEmZMUpjnUMy6lQANku92zUHLpEFIEtAWsZlFylJIq1MynplzOOFBcbpv2LLTvzJhARL3mrld2YnUjKX/uHGF+0J6pswlkqDslRFG0CQwKmsHHGkeYmaa8FOy5eed30wuEELsWUrMMoAqSHqSeBvDcpmYiYou4NnDJSNKB9PUjrFGBwS5gZJZALLWS4c0pxNkjk7NBszaSUAypDkgkKVpwNSLmmnLnBbs5/gjiimWO7QF5hQ5XUpVLKIfJV6P83hJiEZHAYK95WiRwTz51tSGRQoBgN/VXwjx18fHWBZOBMwt7qan4Ui2ZSrE+mkBDLQDh8GqZuyxQ6m559OUNpOACGQkZlqv/ADo37daOQIKRMCf6ctrEKX7JNedkMKMXL6QDM2qlIIl71wVn3jmcFPAAP+VjuVh2y3aalJQJdCFE5gk1W1KmhIo1B4iwSTQSWJA5W8ImvEK870vF8iShnUbMCVWBOgAuag/lGQa4i9Uun45jwy/D5waqZLZ0pJJNCqlP7aN0gda/wR1jLYOpEVlMXqeIFMEJQREFCLyIrUmCmApKYiRFxEVkQyFZURD/ALJYMLmKmKZpY9VOB+cxCNo3HZHDJElz75Ki1TQsBrRgTE80qich4tTFnPhQgl2AenHjA6phV7Luz0ACTmOoU9uusW/qAEpUkhJqCl83BtQ+hqRaK54zBgylLy13jpcAWpXqbxkrRyFGPlhbjKM5Fbgh7gUPTzjMbbwrpzAEKR7Tg2JP/N+MfRVyAgaEtUxgtrLUZyxbNRQu4b0MUxtxkg6kjKqiBi2YhiQbikeIQVEJAcksBxJj0r1ZBobdmsEFLMxfsJoKO6uQ5D5iNQJ9wlIHMsbPxp4RXgcAUS0o4CvMmp9XghUgD6fePMyZecmzbCCjGitM4gh6HQhq/n0jyYSQ7anl5NFW0ipLBCMxJ1LBI4nU9BHS8OhQ31zVK4Bkp8Kepiaj5sLZRjVZhR3HWMRipRStQIIqbhqPH0s5WCEpLM7qOb1NXgVWGSVAkJJSQoOAQ4LihjThzOD6IZIckLOzfZVOUTcSDWqJZpTivr8PnwjVrxAFEsOTaD5RAT86UqJqb+t4Fxe0paTkRvKaurPziOSc8rtjQhGGjzGbQISoBJJAdmzOPCusRwiZkuUhKkEqyDNpluwJOrN5R5gJa1G3N7X0tB+JSEVJc9S0BRdbDKSukZTtgAZROoUCOtvkTGFjR9qsdmUJY0OZWlbD0r4xnI9T6WLjj2YszTkfXNr4hIySxlyygRluBWhUTRyAL871YTDSQpPezVmXJNM11r4pQG8CWYV6R5NwyZaBMxO8Tvpk6kl8vecE/tFVF3okmIy8OZiu+xiyiWBRADKI0QhPuJAbS3nGNaRW/Qfh8XMxAEuQjupSN0ZbtW51VX11eGGCwEuWR3iqlwE1LtR6VpX8JdZ/6mlhIRKQUIFAlAdTvq9H43dxU0irEbXCXGQ5hQgkUe2cgMCzDKKjViwPUwfga41ctVVEJSBQEU0unja58oAxG0xlCUBkitXcF3cuN5VBV9KNCZWOUojMeTJoABVm/hoFXiUlRY5unHh84FDJIPnYrMcqfZ9S/GORJd1GrX/Dc8BygGXn97dD2qVK6CLiM9wenK1Tw5CDQ9+iS8TLSClKe8X7ynGVNHYav68IrnYgqLlFUvlDAM50H3LxfKw9coYcqBvAPB2HwWY5UIMxXKgHU2EG0D/IlJmG4SHtXnoG+sXhBAdVPn5Rp8P2dU28sJVyBU3rBcrs5LTVbzDz3R5PAu+juSRiiBFahH0CVg5JAySkZTWqEgnzDxA4CUaGUmje6ly+vSsDkg8jAFMTwuDXMVkQHN7gADiSaARsZ2zcOSlHdh1vUZk5QkEl2LRDHbMVLlFMklmsSwdqrJT7ayCWzUTpFE0wOZnVYWRJ/wBX+qv/AMaCyU/3FwSelOsVTNpSSa4WWEtZKlA+BGvPz5CYiSpJIUCDz++sDkQUHiMZcnCzMqQqZLU7Od5JB1a4I1D1q3CN5s/DIlywk2QAlwzkpH3DvHzbCIBmSwbFaQemYR9LmYjK+VIzUdxob6WLctIjl7Vgp9Ihj8iQQfZBDEihJrulnKgxB1+cF4UBispY0CXAFw/19IEwKVqXlPusCQXoHZxZ60/BBOKW9Mqfmx1v5PCKu0I/7SjHl9SMpd+Qv5/QRi5yM86asWA83AH38o0qMTmC0uAQSALt1618vJEqWllAtdqqDG543o3jygPsrjRk9roZYPxB/X7NBvZPChc7MfcFOp18ngPa5OcBTOBoA3hxEN+x6aTCzvT8MapOsJ1feaMEVJJuQKUp68eHpFM9QJLM9hQEAcyReIY0KKciTkY7xSA7cK6848lYOXlASshXFTk//ZvSMdIsVSsIEnMtc3NdwUKHlkEXGWHGVYL8QxHlEv0UwE76SGoS4fpR4txKGYAh2EBtnaB50tYdwSOobwgXE4kJD2pBU1dC5L/KM5jJilryp9kGvMw8V4EbCJmKmLSlKSUpavE10LOBBWAlAUPF+NYG7soRma9E9ftFspZKmPp94YFmkkzkoT4Rntu7VCUqJPQc9GivaG0coNaC5jG4/GGYp9BYfXrFsWJzf4IylxV+QebMKlFRuS8Vxxjo9FKjIz61OmS5AC1/1Zrk5lFxnIrl4kMz6AaVEZ6emdipjqd+XsgeNAkacedoPkYJc1WeYQVGoGiUj4RqeXSG3cJloLqyZQHQKrdTtmVWoFXPGPLUqNTQFgtnpl0lgrWRVYel3y6g3rc1dg4hdikBCt8ZEJ01rqAeL1Uf5hriNqoCe7lJBOqqk14hJbgK+EKhhBMOfIXSX5A8VKJLefKkOvbBRVLw6pxKUpyS6uo6kUYm5Nyw4V0honZyZaWogZfaPtPya38G7RbgFpl1XMlu1KlkD9iQDmWSblXRoOnz8CVDvZxWParupCtMqWpXW/0G2c5UZ7EusvLCgBckhIJs7kWt56WjpaADlUuvwpvTo5zfLrD4Y3A5FllApNGzqYAUOhTrdmh3sTZmFKETkScmYZt+54E1YjUU4Q3QrnXgB2N2bBQlSwUg1b3iDprlHqeQu92elGQhAGTMUpAsctCedXryERm4wmciUmoIKlk1ZIt4lotfLupAAFgwYcGibasV8n2TUttCIXbXxTSlFFVUAAuxIB9CYMM+m+A3iD9ooRMlrKigndLFxUE/hsYDfoeKp7RKU4QKMq1LU4RMpBDGz0PK/wCdIomzP3W6gilns8BzJ80AZTwoUvpVmYvzgKaWmPxbIYBSlqWHqmj0qC/1HrHi8SpKmVUaXI/k8jFWFllAmFSkgkhk1qLknhfjEpirHQ6aQt10Uq+wTFoRMypLEcAaOdRw4QmxmDEouUJUk0DJLjrvfYQ4WveOQDp4RIf1ApJSWN+B6R3y8dsPC+hTg8CgqCmlJZi2YqU4qzCg/wBxjUInooO8Qr/IEkMS3EWaF0jZiEJoluZLmBcVh39kF7vaEnl5PSDHHrbNVLR3UvNl3lVLM7n7QrxM8kUSXHmSdKc4Ty9uLAyLJVlDg+9rQnWDFYoJRRbzOIZkPrXW/O8Fv0TUGnsgsmUKkCYq4bMwfgNWhDi5gQGGYN63dhw15xerF1JWoKKdasXBDOfpeE2JxCszPmegcvrQM2jUprDwhopdMWbWm/1OiR9L841vZuWUSg+6VB63H8wHg+z5mTO8WA7ABFdGqedKDzhscHkdK0knjnmP829IbLNOCivB0Y7bYRNw9KH7+EBzUJNQVBviD24FNvKLCj4FEclcOo/KxVPWQBRia8ertEORSjlYpQIdLjQ8qajr6xJWOKnDAN+XaIonzLFgOYL+vhC7ETVLJTLBVxVoPHjA8gezzFYnMrInxiGFkpTegi3D7KKQ6lVvE5syWgElgTrDKSWo7O4N9lM5KlKBAdKaBwa+HDrFE0lIJb+Ikracv4/nBGHxUqY6c29Vn4tDJT8o5xiujF7QxpmFvdHrzgOG238CJczMlsq6hrA8uUKI9bG4uK49Hn5E1J2cY6OMdFCbPpGL24AFJlBkUAGY2Ft5VdSdLmE0/aKlaEnk4A8frWFM8AB1qzNwLIHJxc8kxTJxMxRaUD1Sn7WHWMMcXlGlzSNFhsQpgQEof3i7v19r5QbJwq5hzHMpqDM7HmC9uQ84U9ndjqnzXnVQjeWHuRYFqVPo8fRMVlS6AEhtPhpbr/xEMz4OkUxrl2ZZWDCS/dqV1W2jWAZvx4T48KKg6FAn2QklYdul+kbLEJDM3kflrCqdLBLgkKHmekThlaeyrxRfR3ZHs5NmTUrnhpcveyknMeADHdD36GPo85YSkqNAA/IARk9j7fCElEwAEF8497rzFPDhB8/HJnpEtMyq2oAxYEZmrZnijny2ZpY5ct9BOxkEhc1TvMPkBp8h4GDZmuo8Isly2ASKBIYc2+rxTNWRQg1pSOSpC3crB8bNyy1KN0i3P+aQJsTD5ZaSXdZzknnQP8x1ija0zvSiSk1WQDSoarkeD+EOJiQkJSBQAD/EANAqx3pUVqIJbhfwgDaswS05k0Li1tb6cYtxU4JIGv563hVtVZUqUDQVJ1tCuuh4raPU4klCl5aGnU/xUQKtJtLP+NMoA5aaB+cM5yQmSlGruX04+rwt/SmctKEjqrUDUwHFDqRHY2GVOmEsyEm/EjQfXgI0MzC5Bw4DjppBsrCJlISgBgkAfyTxepgbaE8oQVjeU+VI52f0PlE5QvsmstvXR0uTYL0DsLcfMvCraMxLkk5UgGgZzSgD9XflHuOmlKc8whAKRlckl9QBqXarAVhFMSZqitZZIsnkOPP7wUvBSMb22AzUj2xR9OA0hFicWUkgGl2ejvr46Qz2/tFKE5QwLeQgTZWylzE94sZQapJBJPQcI0Y4qK5S6Gk70uz3BLnTqICQkU/bwry/mH2z9kiXXNnmG5PHloOtT0i/ZkkJDLWRwCUAJ6+1UwwVKCgySF+GVXgDfwJiU8lul0dGNdlYnBNFJII1SbHixD+sVYvELVdeYHU3b6xUp1UJoKH4gPr4xQCQSgpKhexFOI4QlsbREzVJNiR5GLlY5KUvvDg4/mB8RiQhJOZSW+IJMQ7Kp/UzVTVOUIUEIGmcsSo9EmnUw0YNpsDkvIbIwMyZvTHCdEPvF3qvVjWg8eEXzpsuUnQMKAMAweHmJw4CFkMHYA2AbW5cO8JhhpaQFLGdRrv7wP8AakUbq5ibW9hjO+hBMXOxDhCSBx/n+ItldnEAPNWxa1fFvzjDpe0WoAkCoYBqF6esAT8Umm6T1NurVMPGfiOgNN9kxs6QhJKJaVNdy5p1L+EATMQnMVJloDhgyd75dRE8TihpZqtRiPmIWzp1S35zhuzlEE22QZRcupwrpowjMQ02tis26/WFUej9PFxhsx52nPRxjo4x0aDObxGxEqUwQJkzIHzEiXLf4QElNK/yzw6VsJgnvVy5UsgVCmSWsk2r4dIpkITMT/qz8jMCWlJWAC2VO8ohn0AivEYxACUlMyYlIp301QGlgpALcwPW3n8rNNPwars/slEuW4AJfMFBwlWgLHQVYHrrC3HbIXmPdrLE+8+vPWp1Gt4ebPXuJYNugJqSwDUGpFo9xKA+8RwAG6pXIkerDziD3saLcZUY6fJxEo5VgDqC17uAR8ohNmm6k04irc6eMaPaaCu6sl7ZcorqDQ2hTiMMlTZSVFKWKqZlFwzkcdQYVuDe0aIylQmWjVJemkV4TEmTNTNrlDggaEm45H8vDHE4QizUsRcitDYvQwC7uCz+hENXHa2gt3pm02ftPvBmCi+vDl9IZHFK+EEflQ55x8ywO1Dh15FHdNUv1t1H2jVTdso7kqBejNxJt84drVkXBNmgw2JlFSlIKT7rXULPYvx8oFxWIIbKovwYM3M2a0J+zAAlqmEFyGD9TwpoIOxkwJBJIpqfZcn6mkI7o5RSYLiMUyhnHs0cVDG/S/OF68SJmJlpTUUH1PoIKlYhMxS0pcZWUohqkktd+F4z+Kx0xM1SVJBKFKSHcEB23Skghxw4wI97LKF9Gs2vMAWHIAG7wBa9+cN+zuHSE5veWX5s9Pv4x86wxl94hapikglimacya/Co6/3AdYfbXxE2XLPdrVmcZACW0JID1ZLmD/6RLJjbjxNzi1EhTWEZyZtyTLSQAVLagq5e3IGgjLye2UwoKJtQoMVJYKqL8D6RdN2rIyAoDBze/jxgZOV2kLixJakV4nGGYxmUA9kaJB4Qr2ltDIlwXNgLkmKsXtN6mxNAOJ4Nc26w22FsMZhMnkGaQVIluNxIap4qqK6aR0I8dy/6aJP0LtjbGUpffT0KWq4TlOVPNT+0rlYdbaKatTvukaJIII6l/SCVKUipLDSv2iE7EuGJSp/iqfBV4WeRyds6KS6BCUqFDlPBTZeiVfcRUjElJyqdJGh/KiJrLVDkHS9NCOP5ePAmWoB2udW+ohe+zm6JL3jmCmPxPTx4wPPxeQZlKSyR7TNp1tHTJstCStTJSBXgBGN2jjJmLXkQCEaDjzP2imLE5v0vLEnPj+wHbW1VTlkIO7yo/wDEbL/pxtDu5cyWqhzZ08wQB6EesJ8LsDKHIdUcuSpJzAlJTwjXknCUPjgRhjfLlJm52ntQFw+lAOGpMJMVtJ7vYAcGGnyjMztuLS4IB0f2S3ODdmSp05QBlFANipw/QMCfCMr+nklykaFOK0gyZizxirvyssl1Hglz6CH2H7NoSxmHOofEWTzZA+pMMMkuWfapb2WSByCbcLawjcV0Hl6MgvDYgkBMqYT0ZPmSwhphOyilpzT5hH7JZHqoj6Q6KppXQpUBYOUsObi7VghCVKvu/I9GgvJLqKoSTvtmB292Y7pBmS1lSE+0FNmTXiKGMxH0ztPi+7lTUaKSR/kUhIaPmhj0fp5ylH7jHkik9ETHR6Y8jQSZ9FmY6ZNJTh5ajxVlKleIAbzc84rwvZmbMWlU7MEks5UHUeBYuE3Pg0b8YBmSEpWobuZSlFKSxrlchNtHro0LdqFS5c0ZhmSk1Q+UDu5jM6i53VHS4jzFo0c+RbgwC6LFDgG1NPLhyhghaVZkuMyaFgxJA62+8JsMsqCVg1UkFzY0q/I+kMk5Ft7q3F7nmPzSJw2iuRFeNwr0PsijcuFObU5wtTL7sEhIAY0ZLO3tU5QxnYjIlIXUCj1PMP4NAs5bhurCjsNekLOOx4XQp/SCX/UmTUqBIZLbtqG9n4BvOB9uYEIyzEOEKDuaCrcRTQX0gzEo41GooxAeGstYnyVSlADKKC7gV8hanER0JU7Ok35MHtPDiZL/AHXHXTzt48oTbMnpCglSlJGrFrHnreHuM/p0LapLOzjr4+UZLHkiYSmxr46/fxjVhjdx8eBckuNM+jYTFbiUS1lnACWTz6En7xOdg5s4ABaE8BnAPmAWhd2FwqlBa1u4SMr+6FOPAt84HRhgbioLHkQ/4YzyVSpFccbWx3s/Bqws5pqpYTMSU+2HJFiAWJvAe09mzFrmTZaM6FG4IVQAA0Bc26wNsqQg4lCZiQUqdAd6EpoQTUFwB4mC9rLmYfEr7pSkpUlKgAd32WtYnd4RzS8DLly/IrGDRMKUrBUkEEguNWLHQs8aLtBhgJSVSxl7sjLlYZUlk00At5QKnaKJoBmoZX/klsFf5JN/xoeY6TnkEBiVS6HQlix5VaFcnr0LPUk2jCY3DJmAs6ZtSwomZ0Gi+WsQ2klHdIOYJWUZkixUwD/MRdInSxMRLm5wtZZIYZSaAB3cG3pxhhtbCAyqgFT5UqIcpLcdHYuQNeUXVrjyElJW1EyWw8emXNC5gJKXyhnY6nrH0DZ2KkqClZwVLqp6HgAxrlHDrxj59NwhTvLSUsW5EsbHwjQ7KmoUkA5VMGZWnQ6Q+dRexYclo0hnZaJIY3SplJPUH5wsx0shykEH4RUeDmkUzZKvdJ6EuKcz/MeJVMS2YhQ0F+HOl4xpUVZ0udO1QW0JBHrEp+JyjvJhFPny4mKsVtEJDGpNkjVvpzgGThJmJW2mp91I4DnDcU9vSOti7ELmYuYEpcSwfZ06niY1WzNjolJr7R1gjDyJOHSEJKc3g8SYLPtAgVLF+gjsmVyXGKpIWMKdvsnPwgAeFWIlhe4lLqJ/Hg+biSAQDyHHwEFbLwxQ5yhc00a6JfJZ+LXKOAdoWL9BquwXBbAlyGmTMud6qXQAcE1ofX5QXK2gcyjLlqKbDIjeUT7xJoBo/ODZ2BAdcwmYviRQVoEgWHIUirYuKWtcxiciCEhgLu504fMwW3J7BdIr/T4pbEhEtJ+I5ldT/wARXnloO/MMxQIdksASS2ln/KwfNQVOoqJ4PwhPtM5QhtFOegdgeVDCrs79l+LmICitRSBmZsw0Fm0O9BiAMgIN7Ea6+H8QFh0MJYJqpOatSHIfkL0gvHTTlAGj/KKRSS2JPwYntriCVIS9Kkjyb6xlDGl7TyMx7we7TqAQD4gqT/u5RnI9H6dVBGXJ/JkI8iRiMXJH0dGCmCywW/cT6G0aKdN7vKhdEzAyuREpBf8A2pmjxhXImJzDWo0pQinl8/NntnDPh972kqUk1aqJilAdDLVM6sIwSRoUr7KdgzSqSHHskhjch3Bfm/yhqiWCA9a6u3BwW3VeNYQbK2gEqCCKTCEI4ZwFE+BYpH9qRGiwy6M31FW8IyK4zNEnaIzZCgKKCxU5Ve0PGx4wpnTKqdwRYa0pQ8o0SE/CPAP9YBxeFBBKgSw1Grcr/wARecbQsJ0zPiaSogtWw+WlqRanGplkqUWpVnJsx9Wo8dPw5HCheta6HjCbFprX+T5Rnovpizb0/MgzWy510S7sa/MMYz+Hkd4tIU+UHMrp/wAsIfYmSmZLWmxCwUvxDhvJ/SJ7FkGUmbOTVaCgJLOBnUxobqrSNuOaUaXZGUbe+h12fkKmTwViZLoVJSMyErUHICuIsWtSH03ZhSqYvJuuVOADetuNYL2CZ5QZsxYKA26Eirlrs9BAu2Ntypgm4RLldUOaJBBDOdd4AeIhVj/0LLK1J0BTtjzF5ZksBWoZQCgQQ1CwcHnC3tLjgZ8lBRlXlCFg728ouGY1ap8YY7Ex5kYeZgllp2WYoFCVJQc28d4jdUnNegYipjNyypSsiiFBJ/1BUoDAkSzQeZo9i8M8UYv2BZpy/FHuLxJQvKpO4UBQIqLkGo1EV7K23iFzDKSt5KtxBVlpmFMp1A4cxF2PmEy/6clPdqAAmqBXnAIzO9EuQ2kVbSnlaXSpUopIbIwSEpqAAlmqxcNbWJpQjprb1+iklOavx2VbR2RKUossiclTKzGiyCapVo9xa+sNkuuWELcAn5Hn1EUrwbqClHMTcm5LC/rF2InAJ6V9RB3JK30K6i6SE205QXLVLBYpUGPy+0JJEqahXs5uNaw4xBUpKigOSoUPCK8OVpYO4uxD5fG4rDxnUWjnHYVgcfNFAD/apPyV/MebS2koAIHtq0FhzP5pEJ+0yRkSAVcEg06xRhpQCnWaneUXGa2j0J5RNQTdtFN0F7L2d7y95SjV+cPJhCEHgKMCyetLjq8IVYjEFREvNlNEgBJUR4C8erxWKKhLmIKizsUssC2gt1ELLHKTuwpqJfMxISd+3ifKg5RcNqSkS8vdqcVcpCgS7u7/AEgrB4qSQxFTYqI9oAOk2rejCxgeds9C1Fks3ug6cRzgcUtM67L9jY6UtRUqYAoEMlt41Hsg0Nz5c43mz8KhKAEDKm4HWrmPkeJwG8AKOaPQ9Xh7sntFiZaChe+EgEE3ZzR9RSD8Ue0Jk5NUa7buICEFqED8/OULuz4CJOc0zOrq5LfKMjjdo4rELyqCUIPEg+cPpqTMkCXLmMUHIwAclKda+PWBKFeQIanFByAeZ/PGFuMXnVlpp8j8nBhTJ2QVEmbMUoXbNTW7WpBOJXLlhOQgJoizV0PlCKKvTGDcXPAWALtlBFgEli3Ux5iZpAqaceQ+kDTJmZSiTR2Taz3gLbE5YkrWkOzP0Jr6P6nSOpylxQJNJWwD9QFyJqyDULAHAlSBXwUj/ZGXMbI4cJwsw/tUT5BIPXelxjiI9LDVOjHPsi0eNEoi0WJn1mXJUumU8Drb8aG+1MMZkhWQkqygqTqrK4BbiQlv8W96IJkgCgbxP3rrBmylpz5feDhnuCxIpUKBAPG8Y2VutmJ22vu8LnlNmQtJSeYXMWSPBvAGNds/FJmIEwNkUAokOwcO/EJaBtqbOAmsQDK/1JgoAkZVOr+1TtSxJ0aEmx9rKwwm4dgsyEqCCQ4UgHcJ4gpb8MRnG0vwy0Xb15Np+qCUugBRIYAWrxa38Qgx+PWB3jseAoG4dDBOwXXh0lRzLKlqXT3sxuHszdGgTtVL7uShY1//ACT9IScZySplIcYvfZZOllTV3VAV1D8fvAOP2Y6HB5+MO8NKeRLIOYFCSKNRhFOIQ6eERlGUWUjJMxn/AG6YHJTulqiwNfL+DBGy15RMQxPeMAKMCneevJ6CHuypwmImoYONeNKeDgwBMQJUwLsx9LF+MMpu9hrsf4HFBUruc2VLsvKakEVcjlFJlSMPKmT5UgrUglw5zBFlEPcs7m8KMTIMtOaWSU6h6158LQDsXa6UzFKmTsqXP9Igu516VB8G4xphNyWiM8SWzdYqSiYBMbItSa6EUDhTX4eEZ7D4SSmeVC9QUswKVy1JUL0FE0HFXGIKxs2c6ZbMkkP4sLRMbLSgKWSVLGoOYgHQhuI4cdI6eRW6DHHSpiSarESVqly3mSn3QoukJNgFUysABdqQNiNlqmBKg0sruCXTUtoOPhGokYA5s6qgaAZSWAIYW1Z+VoCn4lKc2VBVMG7koSmj1Zmpqr6gxLk7KWB/oVFNZoSrTdV8y0KcRhJgCmKVBiHBbhxg7FbVKVjLmDpLqZKinknKb6AAFoGVMADHOkO1y5ylwTlajgVOobhDRToRtWLBKWnKSpjqAa83HC0TCVzCUywtXxKAKmHhBuIkJJyLuoEitfA9NLw32XtGXLlZAjIwBWBTMoWqCSamzmGbrZy2wfBdnFIQlRT7RVQ7qgUlI3iXZypIeJr2dLCkoTLmKWZedQJDpOUsRvNlzA0/Azm7XCUud6gIQXGU3oPKhFwDCmVtMTElxvrIS4clk+yBycnzjlNJN9nVKT9FPeJeWFbqZZdTJD5aNU1JdtPeMSxWKMzvStAzrOUKAU43Vd2gIY5aoNbh7w/w2xQRnnEIDC7k6mvClY8n4OUpJEshtTLopJJJzPxdy/OJrL7RzinpGJk4ZeQpQSM4IWgO27UPp49RDLYuPMlfdTC4AExBKSSLFjb+YhKnd3PUJlSujuTUg1L368TF02UmZNypYKlyyxZyoHLTz+cVlJNUcotMY4zCyp0pRlkZ7gBW8/J2yl/r1hRsTAYlRCWLlTbwoBS5NBeg1hdiFqlZSXCSWCv7TUc2Bj7PsrDS0ISJdWHtXJFKk83MNixuqvTJ5ciiYfZnZfFrDTJaJY/csEkdEux5GHOzux6EnOZmcnVIYPwryA831jYLSkM/hEEq1GnmDbzaLrDBGR55sSf9glguZZLWJKgPBIYHyj1GyUZqykhPHKNLPxArTn56BKgdWiMxSQ+v1oNIb4oi/LIzG1tmIl5ZkuWFBP8AqJyupSRQ5QnUXpwsYjitkSly0kICpcwF8rMxHEMxIpSGuImpJNhwAv8AlIRrxQlzUoUrKia6W0K7p1oosqurVq0K1FPoZOTXZmO2Ozu6wxEp8ucGY98nu9Bmy/8Axj58qPtuNlCalUtQdKklJOuU0r94+P4rZcxC1oLOhRSebFoaDS0C2AR0FfoF/t844bOXxT5/xFOcfYaPqmKxgGp8Pz8pzhJidokFwpiKhjYjn+aRVMmqWWSCSTo5/LCB17HxK7Syxs5A+sY3JLtllFn0iRNRi5ImJAzLlkAip3gy09Qq46EVvkJ2GRnWAGmGUJajzSVgeW5+CPOzScVhCt0oUhZByKWwcXY+6vKb1tWkP8TOw85a8mcKIZRKC2jFJNCRyoRSkLNpx09hxJwltaFOw54SCigUSX4gn3b8SYr7Q4nPIKPhqPA/Z4U7RlT5a+8TLU6akiqSBYtfThEJm0kzU/Co3SaEHpwjP9y+5dG2otmm7H7Qz4aWCpyglNdALDyaGk2YliKD/iMR2YdCZgIIBU6TxDacWpBszHlyxgzyU6FWO9lHZ/EZcXMQTuqTbiQYK7QLAC1CxdvURnBiMmLQo+yot5/y0M9sz6ZXtWusNJLRyW2Pe8CpIN8yPVvzyjJ4nBCdNQhCQpalAC7VPvNoA56QbszaA/TgFQHdhQ50cD5iLexuJQMXLCiN7MEvxyFvkR4xyi4ytAk1wdms2fgMgCWyh95gKlgQaG5JHl5GfoQtAJLg0qxOYk34hz100i5UtQUrMklKqbqnYF/EEP6wPNxEtIzLWEhKSosUpFGdQJs7muj6F46P5INt9AapJlyihQVSoSCWZwxcmvUUDHlGSRiEhSsqnWXS7DKzalqtlu+phjjNoKWoKOWiWIUQoocPlJTRRHLlzjLjFSlkhRcFShutye4diDQ1N4bjbKrSDZqEpQEoZL0zoYK40YmxOrtXpAW0J7VQoDmA7VA3QDeqh94qmzwlKikpdyUgEOQSKkFLBV9bwNJxIKg2YBvYbce5N9XMUjFrYst6GcpSQhNWU2XM2jM4F3oC9bx5icTklzFkByUZQCOL+o+UKcfjggM+Usz3JqCwH1hRiccZhGiU0A+p5/eKQwynt9Ep5Ix0uzRIxPfG6swalNXe54Br6wy2FMy1QoZ0pUoneJSHqwozC5OpFWjL4Yf01O6VABSXpmCqUs4pD7s7ipf9RYQMyJb1Jd0lKQ1WCRndhWj6V6eJbSDHJ7NFL26sHJmKgwUr4amge5/50g6bikLlkhKUqWwUQ7sxKQ5td4y+IxoQnMhBCypjMUkaNSWLBq1YnnFa9qy5clJ70rWoB0Jela5iS+YN8tIzfD/aWc/ZRtnEDMAo2TcneJc1cU4Q3wAEmR+qmDNMmNlBcDJQprxLP6RlFT0z5iAq2ZjxbN9o221wFploY93KUFLJLuAl2A4ZQR1UIq48UosClezJ9oP9SZlfJmBq9FKSCx0BFRTgY+n9jsaf0mHSTRSAL/Dulz1EfINpY4LmKKQAFF2q1evWN3/08xBmYVSHZUpZyHQghKmPioxZpxgmQlUpcT6cFparP0+UVE0GmogLDTu8SC/XiDrBZlAJU9WPpo35pDp2rRna4umeTpvC/oAPz0gdWKU7Xd+Vg31ESdyp9GYWJc282/3RWAHD2IOrliflHMCB8U7KLscpa9VC3nCDZhRiBNlTN5QIWKbyXYum9jlI4c41QQCGUBwYxidop7nECYNd0EAggPa9RdtYnPWykN6NMhDMcwWLAtUcXa704WEY3tlgO7mJmC0y/wDclga9CPIw82PjxMBUBuhRArUsRXndon2nwneYdakucrLY6ZfaNf2lUd2hWqZ8/YcI9yx55RINAGNzglpmlaZboRL3S4SUqJFd3zqdYOShLlDrUVBzvFIAFgGIyj+0ax0dGB9m4DVPUdyVLl55ZYO5TKpcu2YkAjd86mIpxqklKlqUkkEJlgA5iL1JIHirhHR0O0AukY2ZMUg5AlNQsFlKDAtVwLtYHWKlTJKkZpmVYzZB/T1dmqfWOjoVjC7Hrly0uRuLogIBCj5kAWPD6QNK2WmYO8ClJQzh2JNW+Y4R0dBpUFN2A43YAUknvVBSC4oKagj80hPtbHpSkuSVACwa7g+VPPlHR0Wwfe0mTyScU6FcrGISgsSSouRWn0MCrxpCgpJKSCCCLgirjxj2Oj0FBWZZzdG42B26KsqJpKVAVIc5jWtBS8Ebe2yZgdyEgVLVq9B4P+X6OjHmxxU1RXDJuFszs7aq0pcKAzJZwKsQQc1GsdBClE7LYs9S3RvkT5x0dFYxVBlJ2ccYkVPygHEbSUaJAS+urR0dGjHjj2Zs+WS0L1KJLkuYmhbeEeR0XMiex4McpUsJoQxFb3f0Ys3EwzwhIRkDjvVBJSGZW6C7uGYk0oC44R0dGOeujdj2PRsbEmXKyZUlIY5iGotRSSzua+kJT2SxK1hACD0UwbW4+kdHRgX1E4vRpcVxLl9j5iVf6qAoVYZyA3MgP5Q8xaV9yUIIKyKvQWalNI6OhZZpTaseMElo+f7Tw65Ssqwx0qC48IN7I7XVJnpDkJmEIUBoSWChzD+RMdHR6sUp49nnTbWTR9m2TOZRNGXRgGDgCrcw/lDkOT4UGgEdHRmwfxKZuwbEOKcGPViD8qR4mQScpp40sX9I6Oivkn4CJiQAcwcj7XPHSMT2hd84rmcB2uCI6OhMn8RsfYJ2fxQXJWoE5kqfwaHGFxZIKS5BcEcmL+kdHQnQ8t2YvaWC7uauXoDQ8jUehgbK0dHQRUf/2Q==',
        name: 'bakery',
        nameDetail: '1pcs, Price',
        price: 5.99,
        category: "Bakery & Snacks",
        quantity: 1
    },
    {
        img:'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTA9FI0zltxYlAoAhUftvANQDIAO-LS714WI4eGZbEDRJUkFkLq5uaPvoFrcVqzKT410lo&usqp=CAU',
        name: 'bread',
        nameDetail: '1pcs, Price',
        price: 5.99,
        category: "Bakery & Snacks",
        quantity: 1
    },
    {
        img: banana,
        name: 'banana',
        nameDetail: '1kg, Price',
        price: 4.99,
        category: "Fresh Fruits& Vegetable",
        quantity: 1

    },
    {
        img: apple,
        name: 'apple',
        nameDetail: '1kg, Price',
        price: 4.99,
        category: "Fresh Fruits& Vegetable",
        quantity: 1

    },

    {
        img: Fruit1,
        word: 'Fresh Fruits& Vegetable',
        color: 'rgba(83, 177, 117, 0.1)',
        name: 'explore',
    },
    {
        img: Oil1,
        word: 'Cooking Oil& Ghee',
        color: 'rgba(248, 164, 76, 0.1)',
        name: 'explore',
    },
    {
        img: Meat1,
        word: 'Meat & Fish',
        color: 'rgba(247, 165, 147, 0.25)',
        name: 'explore',
    },
    {
        img: Bakery1,
        word: 'Bakery & Snacks',
        color: 'rgba(211, 176, 224, 0.25)',
        name: 'explore',
    },
    {
        img: Dairy1,
        word: 'Dairy & Eggs',
        color: 'rgba(253, 229, 152, 0.25)',
        name: 'explore',
    },
    {
        img: Beverages1,
        word: 'Beverages',
        color: 'rgba(183, 223, 245, 0.25)',
        name: 'explore',
    },
]